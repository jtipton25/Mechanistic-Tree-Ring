#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Binds two matrices with the same number of rows together into a common matrix in a fashion similar to cbind in R
//' 
//' @param A A matrix
//' @param B A matrix
//' 
//' \code{cbindARMA()} returns a matrix with the same number of rows as both \code{A} and \code{B} and the number of columns of \code{A} plus the number of columns \code{B} giving a matrix, with some abuse of notation of the form \code{[A B]}. Note that there is no way to deal with missing values in this function and this requires the number of rows of \code{A} to be the same as the number of rows of \code{B} (If this isn't true, behavior of the function is not guaranteed).
//' 
//' @export
//[[Rcpp::export]]
arma::mat cbindARMA(const arma::mat & A, const arma::mat & B){
	int nrows = A.n_rows;		
	int ncolsA = A.n_cols;
	int ncolsB = B.n_cols;
	arma::mat out(nrows, ncolsA + ncolsB);
	for(int i = 0; i < ncolsA + ncolsB; i++){
		if(i < ncolsA){
			out.col(i) = A.col(i);
		} else {
			out.col(i) = B.col(i - ncolsA);
		}
	}
	return(out);
}
