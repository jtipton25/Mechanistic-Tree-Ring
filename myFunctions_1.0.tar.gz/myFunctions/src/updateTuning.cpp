#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(cpp)]]

using namespace Rcpp;
using namespace arma;

// //' Adaptively updates tuning parameters in a MCMC chain
// //'
// //' @param k The MCMC iteration
// //' @param accept_tmp A double or numeric vector that gives the acceptance rate over the last 50 iterations
// //' @param tune A double or numeric vector that is the current random walk tuning standard deviations
// //' @param x A numeric vector of the current state to be sampled
// //' @param mu A numeric vector that is the running mean of the MCMC samples
// //' @param Sig A numeric matrix that is the running covariance of the MCMC samples
// //' @export

void updateTuning(const int k, double& accept_tmp, double& tune){
  double delta = 1.0 / sqrt(k);
  if(accept_tmp > 0.44){
    tune = exp(log(tune) + delta);
  } else {
    tune = exp(log(tune) - delta);
  }
  accept_tmp = 0;
}

void updateTuningVec(const int k, arma::vec& accept_tmp, arma::vec& tune){
  double delta = 1.0 / sqrt(k);
  int n = tune.n_elem;
  for(int i = 0; i < n; i++){
    if(accept_tmp(i) > 0.44){
      tune(i) = exp(log(tune(i)) + delta);
    } else {
      tune(i) = exp(log(tune(i)) - delta);
    }
    accept_tmp(i) = 0;
  }
}

void updateTuningMV(const int& k, const arma::vec& x, arma::vec& mu,
                    arma::mat& Sig){
  double delta = 1.0 / (k + 1.0);
  arma::vec tmp = (x - mu);
  mu += delta * tmp;
  Sig += delta * (tmp * tmp.t() - Sig);
}
