#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

const double log2pi = std::log(2.0 * M_PI);

// [[Rcpp::export]]
double dlnormARMA(const double& x, const double& mu, 
											const double& s2, const bool logarithm = true){
  double logval = - 0.5 * (log2pi + log(s2)) - log(x) - 
                  0.5 / s2 * pow(log(x) - mu, 2);
  if(logarithm){
    return(logval);
  } else {
    return(exp(logval));
  }
}
