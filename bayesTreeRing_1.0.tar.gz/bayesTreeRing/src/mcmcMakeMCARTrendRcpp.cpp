#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include "myFunctionsHeader.h"
#include "samplePhi.h"
#include "sampleRho.h"
#include "sampleOmega.h"
#include "sampleSigmaSquaredW.h"
// [[Rcpp::interfaces(r)]]

using namespace Rcpp;
using namespace arma;

//const double log2pi = std::log(2.0 * M_PI);
	
//' An MCMC sampler for the MCAR climate model with trend
//'
//' @param climate A numeric matrix of climate data
//' @param params A List of model parameters
//' @export
// [[Rcpp::export]]
List mcmcMCAR(arma::mat climate, List params){
   
	//
	// load parameters
	//
	
	double mu_beta_0 = params["mu_beta_0"];
	double s2_beta_0 = params["s2_beta_0"];
	double mu_beta_1 = params["mu_beta_1"];
	double s2_beta_1 = params["s2_beta_1"];
	double alpha_s2_W = params["alpha_s2_W"];
	double beta_s2_W = params["beta_s2_W"];
	double alpha_rho_one = params["alpha_rho_one"];
	double beta_rho_one = params["beta_rho_one"];
	double alpha_rho_two = params["alpha_rho_two"];
	double beta_rho_two = params["beta_rho_two"];
	double alpha_phi_one = params["alpha_phi_one"];
	double beta_phi_one = params["beta_phi_one"];
	double alpha_phi_two = params["alpha_phi_two"];
	double beta_phi_two = params["beta_phi_two"];
	double phi_one_tune = params["phi_one_tune"];
	double phi_two_tune = params["phi_two_tune"];
	double rho_one_tune = params["rho_one_tune"];
	double rho_two_tune = params["rho_two_tune"];
	double omega_tune = params["omega_tune"];
  int n_mcmc = params["n_mcmc"];
	
	
	int t = climate.n_cols;
	double phi_lower = - 1;
	double phi_upper = 1;
	double rho_lower = - 1;
	double rho_upper = 1;
	double omega_lower = - 1;
	double omega_upper = 1;
	arma::vec J(24, fill::zeros);
	for(int i = 0; i < 12; i++){
		J(i) = 1;
	}
	arma::rowvec tJ = J.t();
  
	arma::mat I12(12, 12, fill::eye);
	double phi_one = R::rbeta(alpha_phi_one, beta_phi_one) * (phi_upper - phi_lower) + phi_lower;
	double phi_two = R::rbeta(alpha_phi_two, beta_phi_two) * (phi_upper - phi_lower) + phi_lower;
	arma::vec phi_vec(24);
	for(int i = 0; i < 24; i++){
		if(i < 12){
			phi_vec(i) = phi_one;
		} else {
			phi_vec(i) = phi_two;
		}
	}

	double rho_one = R::rbeta(alpha_rho_one, beta_rho_one) * (rho_upper - rho_lower) + rho_lower;
	double rho_two = R::rbeta(alpha_rho_two, beta_rho_two) * (rho_upper - rho_lower) + rho_lower;
	double omega = R::runif(omega_lower, omega_upper);
	double s2_W = 1.0 / R::rgamma(alpha_s2_W, 1.0 / beta_s2_W);
  arma::mat Q_1_inv = makeQinv(rho_one, 12);
	arma::mat Q_1_minus_one_half = chol(Q_1_inv);
	arma::mat Q_2_inv = makeQinv(rho_two, 12);
	arma::mat Q_2_minus_one_half = chol(Q_2_inv);
	arma::mat Q_upper_right = Q_1_minus_one_half.t() * Q_2_minus_one_half;
	arma::mat tmpMatA1 = 1.0 / (1.0 - pow(omega, 2)) * Q_1_inv;
	arma::mat tmpMatA2 = - omega / (1.0 - pow(omega, 2)) * Q_upper_right;
	arma::mat Q_inv_tmp1 = cbindARMA(tmpMatA1, tmpMatA2);
	arma::mat tmpMatB1 =  - omega / (1.0 - pow(omega, 2)) * Q_upper_right.t();
	arma::mat tmpMatB2 = Q_2_inv / (1.0 - pow(omega, 2));
	arma::mat Q_inv_tmp2 = cbindARMA(tmpMatB1, tmpMatB2);
	arma::mat Q_inv = rbindARMA(Q_inv_tmp1, Q_inv_tmp2);
	arma::mat Sigma_inv = 1.0 / s2_W * Q_inv;
	double det_Sigma = - logDet(Sigma_inv);

	double beta_0 = R::rnorm(mu_beta_0, sqrt(s2_beta_0));
	double beta_1 = R::rnorm(mu_beta_1, sqrt(s2_beta_1));

	//
	// save variables
	//
	
	int n_burn = n_mcmc / 2;
	int n_save = n_mcmc - n_burn;
	arma::vec beta_0_save(n_save, fill::zeros);
	arma::vec beta_1_save(n_save, fill::zeros);
	arma::vec phi_one_save(n_save, fill::zeros);
	double phi_one_accept = 0;
  arma::vec phi_two_save(n_save, fill::zeros);
	double phi_two_accept = 0;
	arma::vec rho_one_save(n_save, fill::zeros);
	double rho_one_accept = 0;
	arma::vec rho_two_save(n_save, fill::zeros);
	double rho_two_accept = 0;
	arma::vec omega_save(n_save, fill::zeros);
	double omega_accept = 0;
	arma::vec s2_W_save(n_save, fill::zeros);
	arma::vec log_deviance(n_save, fill::zeros);
//	arma::cube y_pred(t - 1, 24, n_save, fill::zeros);
	
	//
	// Run MCMC
	//
	
	Rcout << "\n\n" << "Starting MCAR model fit, will run for " << n_mcmc << " iterations\n\n";
	for(int k = 0; k < n_mcmc; k++){
  	if((k + 1) % 100 == 0){
    	Rcout << " " << k + 1;
    }
		
    Rcpp::checkUserInterrupt();
    
		//
		// sample phi_one
		//
		
		double phi_one_star = R::rnorm(phi_one, phi_one_tune);
		arma::vec phi_vec_star(24);
		if(phi_one_star > phi_lower && phi_one_star < phi_upper){
			for(int i = 0; i < 24; i++){
				if(i < 12){
					phi_vec_star(i) = phi_one_star;
				} else {
					phi_vec_star(i) = phi_two;
				}
			}
			double x_star = (phi_one_star - phi_lower) / (phi_upper - phi_lower);
			double x = (phi_one - phi_lower) / (phi_upper - phi_lower);
    	double mh_log = samplePhi(climate, phi_vec, phi_vec_star, Sigma_inv, t,
    														beta_0, beta_1, J) + (alpha_phi_one - 1.0) * log(x_star) + 
    														(beta_phi_one - 1.0) * log(1 - x_star) - 
    														((alpha_phi_one - 1.0) * log(x) + 
    														(beta_phi_one - 1.0) * log(1 - x));
			double mh = exp(mh_log);
			if(mh > R::runif(0, 1)){
				phi_one = phi_one_star;
				phi_vec = phi_vec_star;
      	phi_one_accept += 1.0 / n_mcmc;
			}		
		}
		
		//
		// sample phi_two
		//
		
		double phi_two_star = R::rnorm(phi_two, phi_two_tune);
		if(phi_two_star > phi_lower && phi_two_star < phi_upper){
			for(int i = 0; i < 24; i++){
				if(i < 12){
					phi_vec_star(i) = phi_one;
				} else {
					phi_vec_star(i) = phi_two_star;
				}
			}
			double x_star = (phi_two_star - phi_lower) / (phi_upper - phi_lower);
			double x = (phi_two - phi_lower) / (phi_upper - phi_lower);
			double mh_log = samplePhi(climate, phi_vec, phi_vec_star, Sigma_inv, t,
																beta_0, beta_1, J) +  + (alpha_phi_two - 1.0) * log(x_star) + 
    														(beta_phi_two - 1.0) * log(1 - x_star) - 
    														((alpha_phi_two - 1.0) * log(x) + 
    														(beta_phi_two - 1.0) * log(1 - x));
			double mh = exp(mh_log);
			if(mh > R::runif(0, 1)){
				phi_two = phi_two_star;
				phi_vec = phi_vec_star;
				phi_two_accept += 1.0 / n_mcmc;
			}		
		}

		//
		// sample rho_one
		//
		
		double rho_one_star = R::rnorm(rho_one, rho_one_tune);
		if(rho_one_star > rho_lower && rho_one_star < rho_upper){
			arma::mat Q_1_inv_star = makeQinv(rho_one_star, 12);
			arma::mat Q_1_minus_one_half_star = chol(Q_1_inv_star);
			arma::mat Q_upper_right_star = Q_1_minus_one_half_star.t() * Q_2_minus_one_half;
			arma::mat tmpA1_star = Q_1_inv_star / (1.0 - pow(omega, 2));
			arma::mat tmpA2_star = - omega / (1.0 - pow(omega, 2)) * Q_upper_right_star;
			arma::mat Q_inv_tmp1_star = cbindARMA(tmpA1_star, tmpA2_star);
			arma::mat tmpB1_star = - omega / (1.0 - pow(omega, 2)) * Q_upper_right_star.t();
			arma::mat tmpB2_star = Q_2_inv / (1.0 - pow(omega, 2));																						
			arma::mat Q_inv_tmp2_star = cbindARMA(tmpB1_star, tmpB2_star);
			arma::mat Q_inv_star = rbindARMA(Q_inv_tmp1_star, Q_inv_tmp2_star);
			arma::mat Sigma_inv_star = 1.0 / s2_W * Q_inv_star;
			double det_Sigma_star = - logDet(Sigma_inv_star);
			double x_star = (rho_one_star - rho_lower) / (rho_upper - rho_lower);
			double x = (rho_one - rho_lower) / (rho_upper - rho_lower);
			double mh_log = 
			// log likelihood of proposal under model - log likelihood of current value under model
				sampleRho(climate, phi_vec, Sigma_inv, Sigma_inv_star, det_Sigma, det_Sigma_star, t,
																beta_0, beta_1, J) + 
																// likelihood of proposal under prior
																(alpha_rho_one - 1.0) * log(x_star) + 
    														(beta_rho_one - 1.0) * log(1 - x_star) - 
    														// likelihood of current value under prior
    														((alpha_rho_one - 1.0) * log(x) + 
    														(beta_rho_one - 1.0) * log(1 - x));
			double mh = exp(mh_log);
			if(mh > R::runif(0, 1)){
			  rho_one = rho_one_star;
		  	Q_1_inv = Q_1_inv_star;
			  Q_1_minus_one_half = Q_1_minus_one_half_star;
			  Q_upper_right = Q_upper_right_star;
			  Q_inv = Q_inv_star;
		  	Sigma_inv = Sigma_inv_star;
			  det_Sigma = det_Sigma_star;
			  rho_one_accept = rho_one_accept + 1.0 / n_mcmc;
			}
		}

		//
		// sample rho_two
		//
		
		double rho_two_star = R::rnorm(rho_two, rho_two_tune);
		if(rho_two_star > rho_lower && rho_two_star < rho_upper){
			arma::mat Q_2_inv_star = makeQinv(rho_two_star, 12);
			arma::mat Q_2_minus_one_half_star = chol(Q_2_inv_star);
			arma::mat Q_upper_right_star = Q_1_minus_one_half.t() * Q_2_minus_one_half_star;
			arma::mat tmpA1_star = Q_1_inv / (1.0 - pow(omega, 2));
			arma::mat tmpA2_star = - omega / (1.0 - pow(omega, 2)) * Q_upper_right_star;
			arma::mat Q_inv_tmp1_star = cbindARMA(tmpA1_star, tmpA2_star);
			arma::mat tmpB1_star = - omega / (1.0 - pow(omega, 2)) * Q_upper_right_star.t();
			arma::mat tmpB2_star = Q_2_inv_star / (1.0 - pow(omega, 2));																						
			arma::mat Q_inv_tmp2_star = cbindARMA(tmpB1_star, tmpB2_star);
			arma::mat Q_inv_star = rbindARMA(Q_inv_tmp1_star, Q_inv_tmp2_star);
			arma::mat Sigma_inv_star = 1.0 / s2_W * Q_inv_star;
			double det_Sigma_star = - logDet(Sigma_inv_star);			
			double x_star = (rho_two_star - rho_lower) / (rho_upper - rho_lower);
			double x = (rho_two - rho_lower) / (rho_upper - rho_lower);
			double mh_log = 
			// log likelihood of proposal under model - log likelihood of current value under model
				sampleRho(climate, phi_vec, Sigma_inv, Sigma_inv_star, det_Sigma, det_Sigma_star, t,
																beta_0, beta_1, J) + 
																// likelihood of proposal under prior
																(alpha_rho_two - 1.0) * log(x_star) + 
    														(beta_rho_two - 1.0) * log(1 - x_star) - 
    														// likelihood of current value under prior
    														((alpha_rho_two - 1.0) * log(x) + 
    														(beta_rho_two - 1.0) * log(1 - x));
			double mh = exp(mh_log);
			if(mh > R::runif(0, 1)){
			  rho_two = rho_two_star;
		  	Q_2_inv = Q_2_inv_star;
			  Q_2_minus_one_half = Q_2_minus_one_half_star;
			  Q_upper_right = Q_upper_right_star;
			  Q_inv = Q_inv_star;
		  	Sigma_inv = Sigma_inv_star;
			  det_Sigma = det_Sigma_star;
			  rho_two_accept += 1.0 / n_mcmc;
			}
		}
		
		//
		// sample omega
		//
		
		double omega_star = R::rnorm(omega, omega_tune);
		if(omega_star > omega_lower && omega_star < omega_upper){
			arma::mat tmpA1_star = Q_1_inv / (1.0 - pow(omega_star, 2));
			arma::mat tmpA2_star = - omega_star / (1.0 - pow(omega_star, 2)) * Q_upper_right;
			arma::mat Q_inv_tmp1_star = cbindARMA(tmpA1_star, tmpA2_star);
			arma::mat tmpB1_star = - omega_star / (1.0 - pow(omega_star, 2)) * Q_upper_right.t();
			arma::mat tmpB2_star = Q_2_inv / (1.0 - pow(omega_star, 2));																						
			arma::mat Q_inv_tmp2_star = cbindARMA(tmpB1_star, tmpB2_star);
			arma::mat Q_inv_star = rbindARMA(Q_inv_tmp1_star, Q_inv_tmp2_star);
			arma::mat Sigma_inv_star = 1.0 / s2_W * Q_inv_star;
			double det_Sigma_star = - logDet(Sigma_inv_star);
			double mh = 
			// likelihood of proposal 
			sampleOmega(climate, phi_vec, Sigma_inv, Sigma_inv_star, 
															det_Sigma, det_Sigma_star, t , beta_0, beta_1, J);
			if(mh > R::runif(0, 1)){
				omega = omega_star;
				Q_inv = Q_inv_star;
				Sigma_inv = Sigma_inv_star;
				det_Sigma = det_Sigma_star;
				omega_accept += 1.0 / n_mcmc;
			}
		}
		
		//
		// sample s2_W
		//
		
		s2_W = 1.0 / R::rgamma(alpha_s2_W + 24 * (t - 1) / 2, 1.0 / 
													(beta_s2_W + 0.5 * 
													sampleSigmaSquaredW(climate, phi_vec, Q_inv, t,
																							beta_0, beta_1, J)));
		Sigma_inv = 1.0 / s2_W * Q_inv;
		det_Sigma = - logDet(Sigma_inv);
		
		// 
		// sample beta_0
		//
		
		arma::vec Jphi_vecJ = - J + phi_vec % J;
		arma::rowvec tJphi_vecJ = Jphi_vecJ.t();
		double A0 = (t - 1) * as_scalar(tJphi_vecJ * Sigma_inv * Jphi_vecJ) + 1.0 / s2_beta_0;
		double b0 = mu_beta_0 / s2_beta_0;
		for(int i = 1; i < t; i++){
			b0 += - as_scalar(tJphi_vecJ * Sigma_inv * (climate.col(i) - beta_1 * i * J - 
																				phi_vec % (climate.col(i - 1) - beta_1 * 
																									(i - 1) * J)));
		}
		beta_0 = rMVNArmaScalar(A0, b0);
		
		// 
		// sample beta_1
		//
		
		double A1 = 1.0 / s2_beta_1;
		double b1 = mu_beta_1 / s2_beta_1;
		for(int i = 1; i < t; i++){
			arma::vec Jphi_vecJ = ( - i * J + (i - 1) * phi_vec % J);
			arma::rowvec tJphi_vecJ = Jphi_vecJ.t();
			A1 += as_scalar(tJphi_vecJ * Sigma_inv * Jphi_vecJ);// + 1.0 / s2_beta_1;
			b1 += - as_scalar(tJphi_vecJ * Sigma_inv * (climate.col(i) - beta_0 * J - 
																				phi_vec % (climate.col(i - 1) - 
																										beta_0 * J)));
		}
		beta_1 = rMVNArmaScalar(A1, b1);
		
		//
		// save variables
		//
		
		if(k >= n_burn){
			int ktmp = k - n_burn;
			
			//
			// One step ahead posterior predictions
			//
			
// 			mat Sigma = solve_sympd(Sigma_inv);
// 			for(l in 2:t){
//				y_pred[l - 1, , ktmp] = mvrnormArma(1, beta_0 * J + beta_1 * (l - 1) * J +
//																						phi_vec % (climate[, l - 1] - beta_0 * J -
//																											beta_1 * (l - 2) * J), Sigma);
// 			}
			
			//
			// DIC calculation
			//
		
// 			for(l in 2:t){
//				log_deviance[ktmp] = log_deviance[ktmp] - 24 / 2 * log(2 * pi) - 0.5 * det_Sigma - 0.5 * t(climate[, l] - beta_0 * J - beta_1 * (l - 1)* J - phi_vec % (climate[, l - 1] - beta_0 * J - beta_1 * (l - 2) * J)) * Sigma_inv * (climate[, l] - beta_0 * J - beta_1 * (l - 1)* J - phi_vec % (climate[, l - 1] - beta_0 * J - beta_1 * (l - 2) * J));
// 			}
			
			// save variables
			beta_0_save(ktmp) = beta_0;
			beta_1_save(ktmp) = beta_1;
			phi_one_save(ktmp) = phi_one;
			phi_two_save(ktmp) = phi_two;
			rho_one_save(ktmp) = rho_one;
			rho_two_save(ktmp) = rho_two;
			omega_save(ktmp) = omega;
			s2_W_save(ktmp) = s2_W;
		}
	}


//
	// calculate DIC
	//
	
// 	beta_0_mn = mean(beta_0_save)
// 	beta_1_mn = mean(beta_1_save)
// 	phi_vec_mn = c(rep(mean(phi_one_save), 12), rep(mean(phi_two_save), 12))
// 	Q_1_inv_mn = make_Q_inv(mean(rho_one_save), 12)
// 	Q_1_minus_one_half_mn = chol(Q_1_inv_mn)
// 	Q_2_inv_mn = make_Q_inv(mean(rho_two_save), 12)
// 	Q_2_minus_one_half_mn = chol(Q_2_inv_mn)
// 	Q_upper_right_mn = t(Q_1_minus_one_half_mn) * Q_2_minus_one_half_mn
//   omega_mn = mean(omega_save)
// 	Q_inv_mn = rbind(cbind(Q_1_inv_mn / (1.0 - omega_mn^2), - omega_mn / (1.0 - omega_m^2) * Q_upper_right_mn), cbind( - omega_mn / (1.0 - omega_mn^2) * t(Q_upper_right_mn), Q_2_inv_mn / (1.0 - omega_mn^2)))
// 	Sigma_inv_mn = 1.0 / mean(s2_W_save) * Q_inv_mn
// 	det_Sigma_mn = - logDet(Sigma_inv_mn);
// 	
// 	log_deviance_post = 0
// 	for(l in 2:t){
// 		log_deviance_post = log_deviance_post - 24 / 2 * log(2 * pi) - 0.5 * det_Sigma_mn - 0.5 * t(climate[, l] - beta_0_mn * J - beta_1_mn * (l - 1)* J - phi_vec_mn * (climate[, l - 1] - beta_0_mn * J - beta_1_mn * (l - 2) * J)) * Sigma_inv_mn * (climate[, l] - beta_0_mn * J - beta_1_mn * (l - 1)* J - phi_vec_mn * (climate[, l - 1] - beta_0_mn * J - beta_1_mn * (l - 2) * J))
// 	}
// 	
// 	p_DIC = 2 * (log_deviance_post - mean(log_deviance))
// 	DIC = - 2 * log_deviance_post + 2 * p_DIC
	
	//
	// List output
	//
	
	return(List::create(
		_["beta_0"] = beta_0_save,
		_["beta_1"] = beta_1_save, 
		_["phi_one"] = phi_one_save, 
		_["phi_two"] = phi_two_save, 
		_["rho_one"] = rho_one_save,
		_["rho_two"] = rho_two_save, 
		_["omega"] = omega_save, 
		_["s2_W"] = s2_W_save, 
		_["phi_one_accept"] = phi_one_accept,
		_["phi_two_accept"] = phi_two_accept,
		_["rho_one_accept"] = rho_one_accept, 
		_["rho_two_accept"] = rho_two_accept, 
		_["omega_accept"] = omega_accept));


}
