#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r)]]

using namespace Rcpp;
using namespace arma;

//' Computes a simulated tree ring chronology using a VS-Lite-like growth function
//'
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param day_len A vector of average monthly day lengths, scaled to be between 0 and 1, relative to the longest month
//' @param W A matrix of climate realizations
//' @param Temp_min A numeric vector of VS-Lite-like growth model parameters. The minimum temperature at which a tree will grow.
//' @param Temp_max A numeric vector of VS-Lite-like growth model parameters. The maximum temperature at which tree growth increases.
//' @param P_min A numeric vector of VS-Lite-like growth model parameters. The minimum precipitation at which a tree will grow.
//' @param P_max A numeric vector of VS-Lite-like growth model parameters. The maximum precipitation at which tree growth increases.
//' @param species A numeric vector of species indexes
//' 
//' @return A matrix of simulated tree ring chronologies
//' @export
//[[Rcpp::export]]
arma::mat makeZetaVS(const int& t, const int& p, const arma::vec& day_len, 
                     const arma::mat& W, const arma::vec& Temp_min, 
                     const arma::vec& Temp_max, const arma::vec& P_min, 
                     const arma::vec& P_max, const arma::vec& species){
  arma::mat mu(t, p, fill::zeros);
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, fill::zeros);
      int spec_idx = species(k);
      for(int s = 0; s < 12; s++){
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        arma::vec g(2, fill::zeros);
        if(W_T < Temp_min(spec_idx)){
          g(0) = 0;  
        } else if(W_T > Temp_max(spec_idx)){
          g(0) = 1;
        } else {
          g(0) = (W_T - Temp_min(spec_idx)) /
                 (Temp_max(spec_idx) - Temp_min(spec_idx));
        }
        if(W_P < P_min(spec_idx)){
          g(1) = 0;
        } else if(W_P > P_max(spec_idx)){
          g(1) = 1;
        } else {
          g(1) = (W_P - P_min(spec_idx)) /
                 (P_max(spec_idx) - P_min(spec_idx));
        }
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
  }
  return(mu);
}
