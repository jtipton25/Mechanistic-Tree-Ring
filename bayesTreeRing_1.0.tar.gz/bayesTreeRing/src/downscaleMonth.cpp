#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r)]]

using namespace Rcpp;
using namespace arma;

//' Averages Bayesian Tree Ring model output over a set of months to produce an annual summary
//'
//' @param W_array A 3D R array of model output from the Bayesian Tree Ring model
//' 
//' @return A numeric matrix representing an integrated annual summary of tree ring model output
//' @export
// [[Rcpp::export]]
arma::mat downscaleMonth(NumericVector & W_array) {
//   arma::cube W = myFunctions::readCube(W_array);
  NumericVector vecArray(W_array);
  IntegerVector arrayDims = vecArray.attr("dim");
  arma::cube W(vecArray.begin(), arrayDims(0), arrayDims(1), arrayDims(2));
   int num_months = W.n_rows;
   int t = W.n_cols;
   int n_iter = W.n_slices;
   arma::mat W_month(t, n_iter, fill::zeros);
   for(int i = 0; i < t; i++){
   	for(int j = 0; j < n_iter; j++){
      Rcpp::checkUserInterrupt();
   		for(int k = 0; k < num_months; k++){
   			W_month(i, j) += 1.0 / num_months * W(k, i, j);
   		}
   	}
  }
  return(W_month);
}
