#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a log scale Metropolis-Hastings ratio for sampling the CAR matrix paramter omega
//'
//' @param W A numeric matrix of climate data
//' @param phi_vec A numeric vector representing the annual scale AR parameter in the MCAR climate model
//' @param Sigma_inv A numeric matrix representing the current monthly scale MCAR autocorrelation precision 
//' @param Sigma_inv_star A numeric matrix representing the proposed monthly scale MCAR autocorrelation precision 
//' @param det_Sigma A double representing the current monthly scale MCAR matrix determinant on the log scale
//' @param det_Sigma_star A double representing the proposed monthly scale MCAR matrix determinant on the log scale
//' @param t The number of years in the reconstruction interval
//' @param beta_0 The climate process temperature intercept
//' @param beta_1 The climate process temperature slope
//' @param J A vector of all ones
//' 
//' @return A log scale Metropolis-Hastings ratio for sampling rho
//' @export
//[[Rcpp::export]]
double sampleOmega(const arma::mat& W, const arma::vec& phi_vec, 
                   const arma::mat& Sigma_inv, const arma::mat& Sigma_inv_star,
  							   const double& det_Sigma, const double& det_Sigma_star, 
                   const int& t, const double& beta_0, const double& beta_1, 
                   const arma::vec& J){
	double mh1 = 0;
	double mh2 = 0;
//	double mh;
	for(int i = 1; i < t; i++){
 	  arma::vec tmp = W.col(i) - beta_0 * J - beta_1 * i * J - 
  						       phi_vec %  (W.col(i - 1) - beta_0 * J - beta_1 * (i - 1) * J);
		mh1 += - 0.5 * det_Sigma_star - 0.5 * as_scalar(tmp.t() * Sigma_inv_star * tmp);
		mh2 += - 0.5 * det_Sigma - 0.5 * as_scalar(tmp.t() * Sigma_inv * tmp);
	}
	double mh = exp(mh1 - mh2);
	return(mh);
}
