#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include <myFunctions.h>
// [[Rcpp::interfaces(r)]]

using namespace Rcpp;

// [[Rcpp::export]]
arma::vec makeCRPS(const int& tminusN_T, const arma::mat& W, 
                   const arma::vec& W_true){
  int M = W.n_cols;
  double M_inv = 1.0 / M;
  int M2 = pow(M, 2);
  double M2_inv = 1.0 / M2;
  arma::vec crps(tminusN_T, arma::fill::zeros);
  for(int i = 0; i < tminusN_T; i++){
    for(int k = 0; k < M; k++){
      Rcpp::checkUserInterrupt();
      // absolute deviance
      double tmp = W(i, k) - W_true(i);
      if(tmp < 0){
        crps(i) -= M_inv * tmp;
      } else {
        crps(i) += M_inv * tmp;
      }
      for(int l = k; l < M; l++){
        // sharpness
        double tmp2 = W(i, k) - W(i, l);
        if(tmp2 < 0){
          crps(i) -= M2_inv * tmp2;
        } else {
          crps(i) += M2_inv * tmp2;
        }
      }
    }
  }
  return(crps);
}

//// [[Rcpp::export]]
//arma::vec orderRcpp(arma::vec x) {
//  return(as<arma::vec>(wrap(sort_index( x ))) );
//}
//
////[[Rcpp::export]]
//arma::vec makeCRPSOld(int & tminusN_T, arma::mat & W, arma::vec & W_true){
//  int n_size = W.n_cols;
//  double n_size_inv = 1.0 / n_size;
//  arma::vec Fhat(n_size);
//  for(int i = 0; i < n_size; i++){
//    Fhat(i) = (i + 1.0) / n_size;
//  }
//  arma::vec crps(tminusN_T, arma::fill::zeros  );
//  for(int i = 0; i < tminusN_T; i++){
//    arma::vec idx = orderRcpp(W.row(i).t());
//    for(int k = 0; k < n_size; k++){
//      int idxk = idx(k);
//      if(W(i, idxk) >= W_true(i)){
//  crps(i) += n_size_inv * pow(Fhat(k) - 1, 2);
//      } else {
//  crps(i) += n_size_inv * pow(Fhat(k), 2);
//      }
//    }
//  }
//  return(crps);
//}

//[[Rcpp::export]]
arma::vec makePIT(const int & tminusN_T, const arma::mat& W, const arma::vec& W_true){
  int n_size = W.n_cols;
  double n_size_inv = 1.0 / n_size;
  arma::vec pit(tminusN_T, arma::fill::zeros  );
  for(int i = 0; i < tminusN_T; i++){
    Rcpp::checkUserInterrupt();
    for(int k = 0; k < n_size; k++){
      if(W(i, k) >= W_true(i)){
        pit(i) += n_size_inv;
      }
    }
  }
  return(pit);
}


// [[Rcpp::export]]
arma::vec makeCRPSClimate(const arma::mat& W, const arma::vec& W_true){
  int n = W.n_rows;
  int M = W.n_cols;
  double M_inv = 1.0 / M;
  int M2 = pow(M, 2);
  double M2_inv = 1.0 / M2;
  arma::vec crps(n, arma::fill::zeros);
  for(int i = 0; i < n; i++){
    Rcpp::checkUserInterrupt();
    for(int k = 0; k < M; k++){
      double tmp = W(i, k) - W_true(i);
      if(tmp < 0){
        crps(i) -= M_inv * tmp;
      } else {
        crps(i) += M_inv * tmp;
      }
      for(int l = k; l < M; l++){
        double tmp2 = W(i, k) - W(i, l);
        if(tmp2 < 0){
          crps(i) -= M2_inv * tmp2;
        } else {
          crps(i) += M2_inv * tmp2;
        }
      }
    }
  }
  return(crps);
}

//
// Generate probabilistic predictions under climatology
//

//[[Rcpp::export]]
arma::mat predictClimatology(const int& n_iter, const arma::mat& W){
  int num_month = W.n_rows;
  arma::mat out_mat(556, n_iter);
  arma::vec mu = myFunctions::rowMeans(W);
  arma::vec sd = myFunctions::rowSds(W);
  for(int j = 0; j < n_iter; j++){
    for(int i = 0; i < 556; i++){
      Rcpp::checkUserInterrupt();
      arma::vec tmp(num_month);
      for(int k = 0; k < num_month; k++){
        tmp(k) = R::rnorm(mu(k), sd(k));
      }
      out_mat(i, j) = mean(tmp);
    }
  }
  return(out_mat);
}

