#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a log scale Metropolis-Hastings ratio for sampling the annual scale autocorrelation parameter phi
//'
//' @param W A numeric matrix of climate data
//' @param phi_vec A numeric vector representing the current annual scale AR parameter in the MCAR climate model
//' @param phi_vec_star A numeric vector representing the proposed annual scale AR parameter in the MCAR climate model
//' @param Sigma_inv A numeric matrix representing the monthly scale MCAR autocorrelation precision 
//' @param t The number of years in the reconstruction interval
//' @param beta_0 The climate process temperature intercept
//' @param beta_1 The climate process temperature slope
//' @param J A vector of all ones
//' 
//' @return A log scale Metropolis-Hastings ratio for sampling phi
//' @export
//[[Rcpp::export]]
double samplePhi(const arma::mat& W, const arma::vec& phi_vec, 
                 const arma::vec& phi_vec_star, const arma::mat& Sigma_inv, 
                 const int& t, const double& beta_0, const double& beta_1, 
                 const arma::vec& J){
	double mh1 = 0;
	double mh2 = 0;
//	double mh;
	for(int i = 1; i < t; i++){
		arma::vec W_vec = W.col(i);
		arma::vec W_vec_m1 = W.col(i - 1); 
    arma::vec tmp_star = W_vec - beta_0 * J - beta_1 * i * J - phi_vec_star % 
    							        (W_vec_m1 - beta_0 * J - beta_1 * (i - 1) * J);
    arma::vec tmp = W_vec - beta_0 * J - beta_1 * i * J - phi_vec % 
                     (W_vec_m1 - beta_0 * J - beta_1 * (i - 1) * J);
		mh1 += - 0.5 * as_scalar(tmp_star.t() * Sigma_inv * tmp_star);
		mh2 += - 0.5 * as_scalar(tmp.t() * Sigma_inv * tmp);
	}
	double mh = mh1 - mh2;
	return(mh);
}

