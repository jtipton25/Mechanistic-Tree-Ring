#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include "myFunctionsHeader.h"
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a simulated tree ring chronology using a VS-Lite-like and Probit growth function
//'
//' @param p The number of chonologies
//' @param day_len A vector of average monthly day lengths, scaled to be between 0 and 1, relative to the longest month
//' @param W A vector of climate values generated for use in a Metropolis-Hastings proposal
//' @param gamma_T A numeric vector of Probit growth model parameters. The mean temperature at which a tree will grow.
//' @param xi_T A numeric vector of Probit growth model parameters. The standard deviation of the probit growth function for temperature.
//' @param gamma_P A numeric vector of Probit growth model parameters. The mean precipitation at which a tree will grow.
//' @param xi_P A numeric vector of Probit growth model parameters. The standard deviation of the probit growth function for precipitation.
//' @param Temp_min A numeric vector of VS-Lite-like growth model parameters. The minimum temperature at which a tree will grow.
//' @param Temp_max A numeric vector of VS-Lite-like growth model parameters. The maximum temperature at which tree growth increases.
//' @param P_min A numeric vector of VS-Lite-like growth model parameters. The minimum precipitation at which a tree will grow.
//' @param P_max A numeric vector of VS-Lite-like growth model parameters. The maximum precipitation at which tree growth increases.
//' @param species A numeric vector of species indexes
//' @param x A rowvector of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A matrix of simulated tree ring chronologies
//' @export
// [[Rcpp::export]]
arma::vec makeZetaIndividualMix(const int& p, const arma::vec& day_len, 
                                 const arma::vec& W, const arma::vec& gamma_T,
                                 const arma::vec& xi_T, 
                                 const arma::vec& gamma_P, 
                                 const arma::vec& xi_P, 
                                 const arma::vec& Temp_min, 
                                 const arma::vec& Temp_max, 
                                 const arma::vec& P_min, 
                                 const arma::vec& P_max, 
                                 const arma::vec& species, 
                                 const arma::rowvec& x){
  arma::vec mu(p, fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, fill::zeros);
    int spec_idx = species(k);
    if(x(spec_idx)){//x(spec_idx) == 1
      // probit model
      for(int s = 0; s < 12; s++){
        double W_T = W(s);
        double W_P = exp(W(s + 12));
        arma::vec g(2, fill::zeros);
        double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
        double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
        g(0) = phi(tmpT);
        g(1) = phi(tmpP);
        mu_tmp(s) = day_len(s) * min(g);
      }
    } else {
      //vs-lite model
      for(int s = 0; s < 12; s++){
        double W_T = W(s);
        double W_P = exp(W(s + 12));
        arma::vec g(2, fill::zeros);
        if(W_T < Temp_min(spec_idx)){
          g(0) = 0;  
	} else if(W_T > Temp_max(spec_idx)){
          g(0) = 1;
        } else {
          g(0) = (W_T - Temp_min(spec_idx)) / 
	    (Temp_max(spec_idx) - Temp_min(spec_idx));
	}
	if(W_P < P_min(spec_idx)){
          g(1) = 0;
	} else if(W_P > P_max(spec_idx)){
	  g(1) = 1;
	} else {
          g(1) = (W_P - P_min(spec_idx)) / 
	    (P_max(spec_idx) - P_min(spec_idx));
	}
        mu_tmp(s) = day_len(s) * min(g);
      }
    }
    mu(k) = sum(mu_tmp);
  }
  return(mu);
}