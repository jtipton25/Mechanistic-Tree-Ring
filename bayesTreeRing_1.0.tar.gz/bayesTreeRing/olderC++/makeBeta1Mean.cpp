#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a likelihood component for the full conditional mean of the calibration model slope
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of calibraiton model intercepts
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2 The calibration model variance
//' 
//' @return A vector of kernel for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeBeta1Mean(const arma::mat& y, const arma::mat& H, 
                         const arma::vec& beta_0, const arma::mat& zeta, 
                         const arma::vec& species, const int& t, const int& p,
                         const int& num_species, const arma::vec& s2){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += zeta(i, k) * (y(i, k) - beta_0(species_idx)) / 
                             s2(species_idx);
      }
    }
  }
  return(tmp);
}