arma::vec rowMeans(const arma::mat& X){
  int nRows = X.n_rows;
  arma::vec out(nRows);
  for(int i = 0; i < nRows; i++){
    out(i) = mean(X.row(i));
  }
  return(out);
}

arma::vec rowSds(const arma::mat& X){
  int nRows = X.n_rows;
  arma::vec out(nRows);
  for(int i = 0; i < nRows; i++){
    out(i) = stddev(X.row(i));
  }
  return(out);
}

arma::mat rbindARMA(const arma::mat& A, const arma::mat& B){
  int ncols = A.n_cols;    
  int nrowsA = A.n_rows;
  int nrowsB = B.n_rows;
  arma::mat out(nrowsA + nrowsB, ncols);
  for(int i = 0; i < nrowsA + nrowsB; i++){
    if(i < nrowsA){
      out.row(i) = A.row(i);
    } else {
      out.row(i) = B.row(i - nrowsA);
    }
  }
  return(out);
}

arma::vec rMVNArma(const arma::mat& A, const arma::vec& b){
	int ncols = A.n_cols;
	arma::mat A_chol = chol(A);
	arma::vec devs = arma::randn(ncols);
	arma::vec temp = solve(trimatl(A_chol.t()), b);
	return arma::vec(solve(trimatu(A_chol), temp + devs));
}

double rMVNArmaScalar(const double& a, const double& b){
  double a_inv = 1.0 / a;
  double z = R::rnorm(0, 1);
  return(b * a_inv + z * sqrt(a_inv));
}

arma::mat mvrnormArma(const int& n, const arma::vec& mu, 
                       const arma::mat & Sigma){
   int ncols = Sigma.n_cols;
   arma::mat Z = arma::randn(n, ncols);
   return repmat(mu, 1, n).t() + Z * chol(Sigma);
}
