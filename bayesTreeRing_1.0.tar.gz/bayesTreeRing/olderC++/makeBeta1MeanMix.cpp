#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a likelihood component for the full conditional mean of the probit calibration model slope
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of Probit calibraiton model intercpets
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2 The Probit calibration model variance
//' @param mu_beta_1 The prior mean of beta_0
//' @param s2_beta_1 The prior variance of beta_0
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of kernel for full conditional sampling
//' @export
// [[Rcpp::export]]
arma::vec makeBeta1MeanMix(const arma::mat& y, const arma::mat& H, 
                         const arma::vec& beta_0, const arma::mat& zeta, 
                         const arma::vec& species, const int& t, const int& p,
                         const int& num_species, const arma::vec& s2,
                         const double& mu_beta_1, const double& s2_beta_1, const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
	      int species_idx = species(k);
      	if(x(i, species_idx)){
	        tmp(species_idx) += zeta(i, k) * (y(i, k) - beta_0(species_idx)) / 
	                            s2(species_idx);
      	}
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += mu_beta_1 / s2_beta_1;
  }
  return(tmp);
}

//' Computes a likelihood component for the full conditional mean of the VS-Lite calibration model slope
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0_tilde A vector of VS-lite calibraiton model intercepts
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2_tilde The VS-Lite calibration model variance
//' @param mu_beta_1_tilde The prior mean of beta_0_tilde
//' @param s2_beta_1_tilde The prior variance of beta_0_tilde
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of kernel for full conditional sampling
//' @export
// [[Rcpp::export]]
arma::vec makeBeta1MeanTildeMix(const arma::mat& y, const arma::mat& H, 
                                 const arma::vec& beta_0_tilde, 
                                 const arma::mat& zeta, 
                                 const arma::vec& species, const int& t, 
                                 const int& p, const int& num_species, 
                                 const arma::vec& s2_tilde, 
                                 const double& mu_beta_1_tilde, 
                                 const double& s2_beta_1_tilde, 
                                 const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
      	if(!x(i, species_idx)){
	        tmp(species_idx) += zeta(i, k) * (y(i, k) - beta_0_tilde(species_idx)) / 
	                            s2_tilde(species_idx);
      	}
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += mu_beta_1_tilde / s2_beta_1_tilde;
  }
  return(tmp);
}