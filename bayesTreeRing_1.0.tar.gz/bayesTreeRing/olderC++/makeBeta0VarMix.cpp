#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a likelihood component for the full conditional mean of the probit calibration model intercept
//'
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2 The Probit calibration model variance
//' @param s2_beta_0 The prior variance of beta_0
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of kernel for full conditional sampling
//' @export
// [[Rcpp::export]]
arma::vec makeBeta0VarMix(const arma::mat& H, const arma::vec& s2, 
                           const arma::vec& species, const int& t, 
                           const int& p, const int& num_species, 
                           const double& s2_beta_0, const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
	int species_idx = species(k);
	if(x(i, species_idx)){
	  tmp(species_idx) += 1.0 / s2(species_idx);;
      	}
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += 1.0 / s2_beta_0;
  }
  return(tmp);
}

//' Computes a likelihood component for the full conditional mean of the VS-Lite calibration model intercept
//'
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2_tilde The VS-Lite calibration model variance
//' @param s2_beta_0_tilde The prior variance of beta_0_tilde
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of kernel for full conditional sampling
//' @export
// [[Rcpp::export]]
arma::vec makeBeta0VarTildeMix(const arma::mat& H, 
                           const arma::vec& s2_tilde, 
                           const arma::vec& species, const int& t, 
                           const int& p, const int& num_species, 
                           const double& s2_beta_0_tilde,
                           const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
  int species_idx = species(k);
	if(x(i, species_idx)){
	  tmp(species_idx) += 1.0 / s2_tilde(species_idx);;
      	}
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += 1.0 / s2_beta_0_tilde;
  }
  return(tmp);
}