#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a component for the sampling of probit calibration model variance
//'
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeS2AlphaMix(const arma::mat& H, const arma::vec& species, 
                       const int& t, const int& p, const int& num_species, 
                       const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
      	if(x(i, species_idx)){
          tmp(species_idx) += 1.0;
      	}
      }
    }
  }
  return(tmp);
}

//' Computes a component for the sampling of probtit calibration model variance
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of Probit calibraiton model intercepts
//' @param beta_1 A vector of Probit calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeS2BetaMix(const arma::mat& y, const arma::mat& H, 
                     const arma::vec& beta_0, const arma::vec& beta_1,
                     const arma::mat& zeta, const arma::vec& species, 
                     const int& t, const int& p, const int& num_species,
                     const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
	        tmp(species_idx) += pow(y(i, k) - beta_0(species_idx) - 
				                           beta_1(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

//' Computes a component for the sampling of VS-Lite calibration model variance
//'
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeS2AlphaTildeMix(const arma::mat& H, const arma::vec& species, 
                       const int& t, const int& p, const int& num_species, 
                       const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
      	int species_idx = species(k);
      	if(!x(i, species_idx)){
          tmp(species_idx) += 1.0;
      	}
      }
    }
  }
  return(tmp);
}

//' Computes a component for the sampling of VS-Lite calibration model variance
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0_tilde A vector of VS calibraiton model intercepts
//' @param beta_1_tilde A vector of VS calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeS2BetaTildeMix(const arma::mat& y, const arma::mat& H, 
                           const arma::vec& beta_0_tilde, 
                           const arma::vec& beta_1_tilde,
                           const arma::mat& zeta, const arma::vec& species, 
                           const int& t, const int& p, const int& num_species,
                           const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
	        tmp(species_idx) += pow(y(i, k) - beta_0_tilde(species_idx) - 
				                           beta_1_tilde(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}