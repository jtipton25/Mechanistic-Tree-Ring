#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a component for Gibbs sampling of the MCAR variance parameter sigmaSquaredW
//'
//' @param W A numeric matrix of climate data
//' @param phi_vec A numeric vector representing the annual scale AR parameter in the MCAR climate model
//' @param Q_inv A numeric matrix representing the current monthly scale MCAR autocorrelation precision without the variance parameter 
//' @param t The number of years in the reconstruction interval
//' @param beta_0 The climate process temperature intercept
//' @param beta_1 The climate process temperature slope
//' @param J A vector of all ones
//' 
//' @return A sum for computing a component of the full conditional in Gibbs sampling
//' @export
//[[Rcpp::export]]
double sampleSigmaSquaredW(const arma::mat& W, const arma::vec& phi_vec, 
                           const arma::mat& Q_inv, const int& t, 
  											   const double& beta_0, const double& beta_1, 
                           const arma::vec& J){
	double val = 0;
	for(int i = 1; i < t; i++){
	arma::vec tmp = W.col(i) - beta_0 * J - beta_1 * i * J - 
    				       phi_vec %  (W.col(i - 1) - beta_0 * J - beta_1 * (i - 1) * J);
		val += as_scalar(tmp.t() * Q_inv * tmp);
	}
	return(val);
}

