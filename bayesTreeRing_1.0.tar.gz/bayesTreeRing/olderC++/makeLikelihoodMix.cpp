#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a likelihood component for the climate model sampler
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of Probit calibraiton model intercepts
//' @param beta_1 A vector of Probit calibraiton model slopes
//' @param beta_0_tilde A vector of VS calibraiton model intercepts
//' @param beta_1_tilde A vector of VS calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param s2 The Probit calibration model variance
//' @param s2_tilde The VS-lite calibration model variance
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeLikelihoodMix(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_0, const arma::vec& beta_1,
                             const arma::vec& beta_0_tilde, 
                             const arma::vec& beta_1_tilde,
                             const arma::mat& zeta, const int& t, const int& p,
                             const arma::vec& species, const arma::vec& s2, 
                             const arma::vec& s2_tilde, const arma::mat& x){
  vec tmp(t, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(i) += - 0.5 / s2(species_idx) * 
                     pow(y(i, k) - beta_0(species_idx) -
		                     beta_1(species_idx) * zeta(i, k), 2);
        } else {
          tmp(i) += - 0.5 / s2_tilde(species_idx) * 
	                    pow(y(i, k) - beta_0_tilde(species_idx) -
		                      beta_1_tilde(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

//' Computes a likelihood component for the climate model sampler
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of Probit calibraiton model intercepts
//' @param beta_1 A vector of Probit calibraiton model slopes
//' @param beta_0_tilde A vector of VS calibraiton model intercepts
//' @param beta_1_tilde A vector of VS calibraiton model slopes
//' @param zeta_individual A numeric vector of proposed modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param i The year of the reconstruction interval currently being sampled
//' @param p The number of chonologies
//' @param s2 The Probit calibration model variance
//' @param s2_tilde The VS-lite calibration model variance
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
// [[Rcpp::export]]
double makeLikelihoodIndividualMix(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_0, const arma::vec& beta_1,
                             const arma::vec& beta_0_tilde, 
                             const arma::vec& beta_1_tilde,
                             const arma::vec& zeta_individual, const int& i, 
                             const int& p, const arma::vec& species, 
                             const arma::vec& s2, const arma::vec& s2_tilde,
                             const arma::mat& x){
  double tmp = 0;
  for(int k = 0; k < p; k++){
    if(H(i, k)){      
      int species_idx = species(k);
      if(x(i, species_idx)){
        tmp += - 0.5 / s2(species_idx) * pow(y(i, k) - beta_0(species_idx) - 
  				     beta_1(species_idx) * zeta_individual(k), 2);
      } else {
        tmp += - 0.5 / s2_tilde(species_idx) * pow(y(i, k) - beta_0_tilde(species_idx) - 
						   beta_1_tilde(species_idx) * zeta_individual(k), 2);
      }
    }
  }
  return(tmp);
}

//' Computes a likelihood component for the probit growth model sampler
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of Probit calibraiton model intercepts
//' @param beta_1 A vector of Probit calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2 The Probit calibration model variance
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
// [[Rcpp::export]]
arma::vec makeLikelihoodSpeciesMix(const arma::mat& y, const arma::mat& H, 
                                   const arma::vec& beta_0, 
                                   const arma::vec& beta_1,
                                   const arma::mat& zeta, 
                                   const arma::vec& species, const int& t, 
                                   const int& p, const int& num_species, 
                                   const arma::vec& s2, const arma::mat& x){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(species_idx) += - 0.5 / s2(species_idx) * 
                             pow(y(i, k) - beta_0(species_idx) - 
                                 beta_1(species_idx) * zeta(i, k), 2);
	      }
      }
    }
  }
  return(tmp);
}

//' Computes a likelihood component for the VS-Lite growth model sampler
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0_tilde A vector of VS calibraiton model intercepts
//' @param beta_1_tilde A vector of VS calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2_tilde The VS-lite calibration model variance
//' @param x A matrix of indicators of model type. 0 = VS-lite model and 1 = Probit model
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
// [[Rcpp::export]]
arma::vec makeLikelihoodSpeciesTildeMix(const arma::mat& y, const arma::mat& H,
                                         const arma::vec& beta_0_tilde, 
                                         const arma::vec& beta_1_tilde,
                                         const arma::mat& zeta, 
                                         const arma::vec& species, 
                                         const int& t,
                                         const int& p, const int& num_species,
                                         const arma::vec& s2_tilde, 
                                         const arma::mat& x){
  vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += - 0.5 / s2_tilde(species_idx) *
                               pow(y(i, k) - beta_0_tilde(species_idx) - 
                                   beta_1_tilde(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

//' Computes a likelihood component for the sampling of model choice x
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of calibraiton model intercepts
//' @param beta_1 A vector of calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' @param s2 A vector of calibration model variances
//' 
//' @return A vector of likelihood contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::mat makeLikelihoodPsi(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_0, const arma::vec& beta_1,
                             const arma::mat& zeta, const arma::vec& species, 
                             const int& num_species, const int& t, 
                             const int& p, const arma::vec& s2){
  arma::mat tmp(t, num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        double s2_species = s2(species_idx);
	      tmp(i, species_idx) += - 0.5 * log(2.0 * M_PI * s2_species) - 
                               0.5 / s2_species * 
                               pow(y(i, k) - beta_0(species_idx) - 
                                   beta_1(species_idx) * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}
