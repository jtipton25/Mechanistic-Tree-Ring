#include <RcppArmadillo.h>
//#include <myFunctions.h>
//// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include "myFunctionsHeader.h"
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a simulated tree ring chronology using a Normal/Probit growth function
//'
//' @param p The number of chonologies
//' @param day_len A vector of average monthly day lengths, scaled to be between 0 and 1, relative to the longest month
//' @param W A vector of climate values generated for use in a Metropolis-Hastings proposal
//' @param gamma_T A numeric vector of Probit growth model parameters. The mean temperature at which a tree will grow.
//' @param xi_T A numeric vector of Probit growth model parameters. The standard deviation of the probit growth function for temperature.
//' @param gamma_P A numeric vector of Probit growth model parameters. The mean precipitation at which a tree will grow.
//' @param xi_P A numeric vector of Probit growth model parameters. The standard deviation of the probit growth function for precipitation.
//' @param species A numeric vector of species indexes
//' 
//' @return A matrix of simulated tree ring chronologies
//' @export
//[[Rcpp::export]]
arma::mat makeZetaIndividualNP(const int& p, const arma::vec& day_len,
                                 const arma::vec& W, const arma::vec& gamma_T,
                                 const arma::vec& xi_T, 
                                 const arma::vec& gamma_P,
                                 const arma::vec& xi_P, 
                                 const arma::vec& species){
  arma::vec mu(p, fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, fill::zeros);
      int spec_idx = species(k);
    for(int s = 0; s < 12; s++){
      arma::vec g(2, fill::zeros);
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
      double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
      g(0) = exp( - pow(tmpT, 2));
      g(1) = phi(tmpP);
      mu_tmp(s) = day_len(s) * min(g);
    }
  mu(k) = sum(mu_tmp);
  }
  return(mu);
}

