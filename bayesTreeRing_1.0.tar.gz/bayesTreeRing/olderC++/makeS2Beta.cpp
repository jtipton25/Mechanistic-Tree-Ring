#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//' Computes a kernel for full conditional sampling for the climate model variance
//'
//' @param y A numeric matrix of chronology data
//' @param H A boolean matrix of indicators if the chronology was observed
//' @param beta_0 A vector of calibraiton model intercepts
//' @param beta_1 A vector of calibraiton model slopes
//' @param zeta A numeric matrix of modeled tree ring chronologies
//' @param species A numeric vector of species indexes
//' @param t The number of years in the reconstruction interval
//' @param p The number of chonologies
//' @param num_species The number of unique species
//' 
//' @return A vector of kernel contributions for full conditional sampling
//' @export
//[[Rcpp::export]]
arma::vec makeS2Beta(const arma::mat& y, const arma::mat& H,
                     const arma::vec& beta_0, const arma::vec& beta_1, 
                     const arma::mat& zeta, const arma::vec& species, 
                     const int& t, const int& p, const int& num_species){
  arma::vec tmp(num_species, fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += pow(y(i, k) - beta_0(species_idx) - 
                             beta_1(species_idx) * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

