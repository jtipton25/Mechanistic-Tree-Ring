// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include "myFunctionsHeader.h"

arma::vec makeBeta0MeanMix(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_1, const arma::mat& zeta, 
                             const arma::vec& species, const int& t, 
                             const int& p, const int& num_species, 
                             const arma::vec& s2, const double& mu_beta_0, 
                             const double& s2_beta_0, const arma::mat & x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(species_idx) += (y(i, k) - beta_1(species_idx) * zeta(i, k)) / 
                              s2(species_idx);
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += mu_beta_0 / s2_beta_0;
  }
  return(tmp);
}


arma::vec makeBeta0MeanTildeMix(const arma::mat& y, const arma::mat& H, 
                                 const arma::vec& beta_1_tilde, 
                                 const arma::mat& zeta, 
                                 const arma::vec& species, const int& t,
                                 const int& p, const int& num_species,
                                 const arma::vec& s2_tilde,
                                 const double& mu_beta_0_tilde, 
                                 const double& s2_beta_0_tilde, 
                                 const arma::mat & x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += (y(i, k) - beta_1_tilde(species_idx) * zeta(i, k)) / 
                              s2_tilde(species_idx);
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += mu_beta_0_tilde / s2_beta_0_tilde;
  }
  return(tmp);
}

arma::vec makeBeta0VarMix(const arma::mat& H, const arma::vec& s2, 
                           const arma::vec& species, const int& t, 
                           const int& p, const int& num_species, 
                           const double& s2_beta_0, const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
	int species_idx = species(k);
	if(x(i, species_idx)){
	  tmp(species_idx) += 1.0 / s2(species_idx);;
      	}
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += 1.0 / s2_beta_0;
  }
  return(tmp);
}

arma::vec makeBeta0VarTildeMix(const arma::mat& H, 
                           const arma::vec& s2_tilde, 
                           const arma::vec& species, const int& t, 
                           const int& p, const int& num_species, 
                           const double& s2_beta_0_tilde,
                           const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
  int species_idx = species(k);
  if(x(i, species_idx)){
    tmp(species_idx) += 1.0 / s2_tilde(species_idx);;
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += 1.0 / s2_beta_0_tilde;
  }
  return(tmp);
}

arma::vec makeBeta1MeanMix(const arma::mat& y, const arma::mat& H, 
                         const arma::vec& beta_0, const arma::mat& zeta, 
                         const arma::vec& species, const int& t, const int& p,
                         const int& num_species, const arma::vec& s2,
                         const double& mu_beta_1, const double& s2_beta_1, const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(species_idx) += zeta(i, k) * (y(i, k) - beta_0(species_idx)) / 
                              s2(species_idx);
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += mu_beta_1 / s2_beta_1;
  }
  return(tmp);
}

arma::vec makeBeta1MeanTildeMix(const arma::mat& y, const arma::mat& H, 
                                 const arma::vec& beta_0_tilde, 
                                 const arma::mat& zeta, 
                                 const arma::vec& species, const int& t, 
                                 const int& p, const int& num_species, 
                                 const arma::vec& s2_tilde, 
                                 const double& mu_beta_1_tilde, 
                                 const double& s2_beta_1_tilde, 
                                 const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += zeta(i, k) * (y(i, k) - beta_0_tilde(species_idx)) / 
                              s2_tilde(species_idx);
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += mu_beta_1_tilde / s2_beta_1_tilde;
  }
  return(tmp);
}

arma::vec makeBeta1VarMix(const arma::mat& H, const arma::mat& zeta,
                           const arma::vec& species, const int& t, 
                           const int& p, const int& num_species,
                           const arma::vec& s2, const double& s2_beta_1, 
                           const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){  
          tmp(species_idx) += pow(zeta(i, k), 2) / s2(species_idx);
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += 1.0 / s2_beta_1;
  }
  return(tmp);
}

arma::vec makeBeta1VarTildeMix(const arma::mat& H, const arma::mat& zeta,
                               const arma::vec& species, const int& t, 
                               const int& p, const int& num_species,
                               const arma::vec& s2_tilde, 
                               const double& s2_beta_1_tilde, 
                               const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += pow(zeta(i, k), 2) / s2_tilde(species_idx);
        }
      }
    }
  }
  for(int i = 0; i < num_species; i++){
    tmp(i) += 1.0 / s2_beta_1_tilde;
  }
  return(tmp);
}

arma::vec makeLikelihoodMix(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_0, const arma::vec& beta_1,
                             const arma::vec& beta_0_tilde, 
                             const arma::vec& beta_1_tilde,
                             const arma::mat& zeta, const int& t, const int& p,
                             const arma::vec& species, const arma::vec& s2, 
                             const arma::vec& s2_tilde, const arma::mat& x){
  arma::vec tmp(t, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(i) += - 0.5 / s2(species_idx) * 
                     pow(y(i, k) - beta_0(species_idx) -
                         beta_1(species_idx) * zeta(i, k), 2);
        } else {
          tmp(i) += - 0.5 / s2_tilde(species_idx) * 
                      pow(y(i, k) - beta_0_tilde(species_idx) -
                          beta_1_tilde(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

double makeLikelihoodIndividualMix(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_0, const arma::vec& beta_1,
                             const arma::vec& beta_0_tilde, 
                             const arma::vec& beta_1_tilde,
                             const arma::vec& zeta_individual, const int& i, 
                             const int& p, const arma::vec& species, 
                             const arma::vec& s2, const arma::vec& s2_tilde,
                             const arma::mat& x){
  double tmp = 0;
  for(int k = 0; k < p; k++){
    if(H(i, k)){      
      int species_idx = species(k);
      if(x(i, species_idx)){
        tmp += - 0.5 / s2(species_idx) * pow(y(i, k) - beta_0(species_idx) - 
               beta_1(species_idx) * zeta_individual(k), 2);
      } else {
        tmp += - 0.5 / s2_tilde(species_idx) * pow(y(i, k) - beta_0_tilde(species_idx) - 
               beta_1_tilde(species_idx) * zeta_individual(k), 2);
      }
    }
  }
  return(tmp);
}

arma::vec makeLikelihoodSpeciesMix(const arma::mat& y, const arma::mat& H, 
                                   const arma::vec& beta_0, 
                                   const arma::vec& beta_1,
                                   const arma::mat& zeta, 
                                   const arma::vec& species, const int& t, 
                                   const int& p, const int& num_species, 
                                   const arma::vec& s2, const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(species_idx) += - 0.5 / s2(species_idx) * 
                             pow(y(i, k) - beta_0(species_idx) - 
                                 beta_1(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

arma::vec makeLikelihoodSpeciesTildeMix(const arma::mat& y, const arma::mat& H,
                                         const arma::vec& beta_0_tilde, 
                                         const arma::vec& beta_1_tilde,
                                         const arma::mat& zeta, 
                                         const arma::vec& species, 
                                         const int& t,
                                         const int& p, const int& num_species,
                                         const arma::vec& s2_tilde, 
                                         const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += - 0.5 / s2_tilde(species_idx) *
                               pow(y(i, k) - beta_0_tilde(species_idx) - 
                                   beta_1_tilde(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

arma::mat makeLikelihoodPsi(const arma::mat& y, const arma::mat& H, 
                             const arma::vec& beta_0, const arma::vec& beta_1,
                             const arma::mat& zeta, const arma::vec& species, 
                             const int& num_species, const int& t, 
                             const int& p, const arma::vec& s2){
  arma::mat tmp(t, num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        double s2_species = s2(species_idx);
        tmp(i, species_idx) += - 0.5 * log(2.0 * M_PI * s2_species) - 
                               0.5 / s2_species * 
                               pow(y(i, k) - beta_0(species_idx) - 
                                   beta_1(species_idx) * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

arma::vec makeS2AlphaMix(const arma::mat& H, const arma::vec& species, 
                       const int& t, const int& p, const int& num_species, 
                       const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(species_idx) += 1.0;
        }
      }
    }
  }
  return(tmp);
}

arma::vec makeS2BetaMix(const arma::mat& y, const arma::mat& H, 
                     const arma::vec& beta_0, const arma::vec& beta_1,
                     const arma::mat& zeta, const arma::vec& species, 
                     const int& t, const int& p, const int& num_species,
                     const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(x(i, species_idx)){
          tmp(species_idx) += pow(y(i, k) - beta_0(species_idx) - 
                                   beta_1(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

arma::vec makeS2AlphaTildeMix(const arma::mat& H, const arma::vec& species, 
                       const int& t, const int& p, const int& num_species, 
                       const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += 1.0;
        }
      }
    }
  }
  return(tmp);
}

arma::vec makeS2BetaTildeMix(const arma::mat& y, const arma::mat& H, 
                           const arma::vec& beta_0_tilde, 
                           const arma::vec& beta_1_tilde,
                           const arma::mat& zeta, const arma::vec& species, 
                           const int& t, const int& p, const int& num_species,
                           const arma::mat& x){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        if(!x(i, species_idx)){
          tmp(species_idx) += pow(y(i, k) - beta_0_tilde(species_idx) - 
                                   beta_1_tilde(species_idx) * zeta(i, k), 2);
        }
      }
    }
  }
  return(tmp);
}

arma::mat makeZetaMix(const int& t, const int& p, const arma::vec& day_len, 
                       const arma::mat& W, const arma::vec& gamma_T, 
                       const arma::vec& xi_T, const arma::vec& gamma_P, 
                       const arma::vec& xi_P, const arma::vec& Temp_min, 
                       const arma::vec& Temp_max, const arma::vec& P_min,
                       const arma::vec& P_max, const arma::vec& species, 
                       const arma::mat& x){
  //  int num_species = species.n_elem;
  arma::mat mu(t, p, arma::fill::zeros);
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
      int spec_idx = species(k);
      if(x(i, spec_idx)){//x(i, spec_idx) == 1
        // probit model
        for(int s = 0; s < 12; s++){
          double W_T = W(s, i);
          double W_P = exp(W(s + 12, i));
          arma::vec g(2, arma::fill::zeros);
          double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
          double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
          g(0) = phi(tmpT);
          g(1) = phi(tmpP);
          mu_tmp(s) = day_len(s) * min(g);
        }
      } else {
        //vs-lite model
        for(int s = 0; s < 12; s++){
          double W_T = W(s, i);
          double W_P = exp(W(s + 12, i));
          arma::vec g(2, arma::fill::zeros);
          if(W_T < Temp_min(spec_idx)){
            g(0) = 0;  
          } else if(W_T > Temp_max(spec_idx)){
            g(0) = 1;
          } else {
            g(0) = (W_T - Temp_min(spec_idx)) / (Temp_max(spec_idx) - Temp_min(spec_idx));
          }
          if(W_P < P_min(spec_idx)){
            g(1) = 0;
          } else if(W_P > P_max(spec_idx)){
            g(1) = 1;
          } else {
            g(1) = (W_P - P_min(spec_idx)) / (P_max(spec_idx) - P_min(spec_idx));
          }
          mu_tmp(s) = day_len(s) * min(g);
        }    
      }
      mu(i, k) = sum(mu_tmp);
    }
  }
  return(mu);
}

arma::vec makeZetaIndividualMix(const int& p, const arma::vec& day_len, 
                                 const arma::vec& W, const arma::vec& gamma_T,
                                 const arma::vec& xi_T, 
                                 const arma::vec& gamma_P, 
                                 const arma::vec& xi_P, 
                                 const arma::vec& Temp_min, 
                                 const arma::vec& Temp_max, 
                                 const arma::vec& P_min, 
                                 const arma::vec& P_max, 
                                 const arma::vec& species, 
                                 const arma::rowvec& x){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
    int spec_idx = species(k);
    if(x(spec_idx)){//x(spec_idx) == 1
      // probit model
      for(int s = 0; s < 12; s++){
        double W_T = W(s);
        double W_P = exp(W(s + 12));
        arma::vec g(2, arma::fill::zeros);
        double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
        double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
        g(0) = phi(tmpT);
        g(1) = phi(tmpP);
        mu_tmp(s) = day_len(s) * min(g);
      }
    } else {
      //vs-lite model
      for(int s = 0; s < 12; s++){
        double W_T = W(s);
        double W_P = exp(W(s + 12));
        arma::vec g(2, arma::fill::zeros);
        if(W_T < Temp_min(spec_idx)){
          g(0) = 0;  
        } else if(W_T > Temp_max(spec_idx)){
          g(0) = 1;
        } else {
          g(0) = (W_T - Temp_min(spec_idx)) / 
                 (Temp_max(spec_idx) - Temp_min(spec_idx));
        }
        if(W_P < P_min(spec_idx)){
          g(1) = 0;
        } else if(W_P > P_max(spec_idx)){
          g(1) = 1;
        } else {
          g(1) = (W_P - P_min(spec_idx)) / 
                 (P_max(spec_idx) - P_min(spec_idx));
        }
        mu_tmp(s) = day_len(s) * min(g);
      }
    }
    mu(k) = sum(mu_tmp);
  }
  return(mu);
}