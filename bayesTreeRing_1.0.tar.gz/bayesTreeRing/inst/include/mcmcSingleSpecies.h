// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include "myFunctionsHeader.h"

double makeBeta0(const arma::mat& y, const arma::mat& H, 
                  const double& beta_1, const arma::mat& zeta,
                  const int& t, const int& p, const double& s2){
  double tmp = 0;
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        tmp += (y(i, k) - beta_1 * zeta(i, k)) / s2;
      }
    }
  }
  return(tmp);
}

double makeBeta1Mean(const arma::mat& y, const arma::mat& H, 
                      const double& beta_0, const arma::mat& zeta, 
                      const int& t, const int& p, const double& s2){
  double tmp = 0;
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        tmp += zeta(i, k) * (y(i, k) - beta_0) / s2;
      }
    }
  }
  return(tmp);
}

double makeBeta1Var(const arma::mat& H, const arma::mat& zeta,
                    const int& t, const int& p, const double& s2){
  double tmp = 0;
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        tmp += pow(zeta(i, k), 2) / s2;
      }
    }
  }
  return(tmp);
}

arma::vec makeLikelihood(const arma::mat& y, const arma::mat& H, 
                         const double& beta_0, const double& beta_1,
                         const arma::mat& zeta, const int& t, const int& p,
                         const double& s2){
  arma::vec tmp(t, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        tmp(i) += - 0.5 / s2 * pow(y(i, k) - beta_0 - beta_1 * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

double makeLikelihoodIndividual(const arma::mat& y, const arma::mat& H, 
                                const double& beta_0, const double& beta_1, 
                                const arma::vec& zeta_ind, const int& i,
                                const int& p, const double& s2){
  double tmp = 0;
  for(int k = 0; k < p; k++){
    if(H(i, k)){
      tmp += - 0.5 / s2 * pow(y(i, k) - beta_0 - beta_1 * zeta_ind(k), 2);
    }
  }
  return(tmp);
}


double makeLikelihoodSpecies(const arma::mat& y, const arma::mat& H, 
                              const double& beta_0, const double& beta_1, 
                              const arma::mat& zeta, const int& t, 
                              const int& p, const double& s2){
  double tmp = 0;
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        tmp += - 0.5 / s2 * pow(y(i, k) - beta_0 - beta_1 * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

double makeS2Beta(const arma::mat& y, const arma::mat& H,
                     const double& beta_0, const double& beta_1, 
                     const arma::mat& zeta, const int& t, const int& p){
  double tmp = 0;
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        tmp += pow(y(i, k) - beta_0 - beta_1 * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

arma::mat makeZetaIndividualNP(const int& p, const arma::vec& day_len,
                                const arma::vec& W, const double& gamma_T,
                                const double& xi_T, const double& gamma_P,
                                const double& xi_P){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
    for(int s = 0; s < 12; s++){
      arma::vec g(2, arma::fill::zeros);
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      double tmpT = (W_T - gamma_T) / xi_T;
      double tmpP = (W_P - gamma_P) / xi_P;
      g(0) = exp( - pow(tmpT, 2));
      g(1) = phi(tmpP);
      mu_tmp(s) = day_len(s) * min(g);
    }
  mu(k) = sum(mu_tmp);
  }
  return(mu);
}

arma::mat makeZetaIndividualPro(const int& p, const arma::vec& day_len,
                                 const arma::vec& W, const double& gamma_T,
                                 const double& xi_T, const double& gamma_P,
                                 const double& xi_P){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
    for(int s = 0; s < 12; s++){
      arma::vec g(2, arma::fill::zeros);
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      double tmpT = (W_T - gamma_T) / xi_T;
      double tmpP = (W_P - gamma_P) / xi_P;
      g(0) = phi(tmpT);
      g(1) = phi(tmpP);
      mu_tmp(s) = day_len(s) * min(g);
    }
  mu(k) = sum(mu_tmp);
  }
  return(mu);
}

arma::vec makeZetaIndividualVS(const int& p, const arma::vec& day_len, 
                               const arma::vec& W, const double& Temp_min,
                               const double& Temp_max, const double& P_min, 
                               const double& P_max){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
    for(int s = 0; s < 12; s++){
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      arma::vec g(2, arma::fill::zeros);
      if(W_T < Temp_min){
        g(0) = 0;  
      } else if(W_T > Temp_max){
        g(0) = 1;
      } else {
        g(0) = (W_T - Temp_min) / 
               (Temp_max - Temp_min);
      }
      if(W_P < P_min){
        g(1) = 0;
      } else if(W_P > P_max){
        g(1) = 1;
      } else {
        g(1) = (W_P - P_min) / 
               (P_max - P_min);
      }
      mu_tmp(s) = day_len(s) * min(g);
    }
    mu(k) = sum(mu_tmp);
  }
  return(mu);
}

arma::mat makeZetaNP(const int& t, const int& p, const arma::vec& day_len, 
                       const arma::mat& W, const double& gamma_T, 
                       const double& xi_T, const double& gamma_P, 
                       const double& xi_P){
  arma::mat mu(t, p, arma::fill::zeros);
  int idx = 0;
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
      for(int s = 0; s < 12; s++){
        arma::vec g(2, arma::fill::zeros);
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        double tmpT = (W_T - gamma_T) / xi_T;
        double tmpP = (W_P - gamma_P) / xi_P;
        g(0) = exp( - pow(tmpT, 2));
        g(1) = phi(tmpP);
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
    idx = idx + 12;
  }
  return(mu);
}

arma::mat makeZetaPro(const int& t, const int& p, const arma::vec& day_len, 
                       const arma::mat& W, const double& gamma_T, 
                       const double& xi_T, const double& gamma_P, 
                       const double& xi_P){
  arma::mat mu(t, p, arma::fill::zeros);
  int idx = 0;
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
      for(int s = 0; s < 12; s++){
        arma::vec g(2, arma::fill::zeros);
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        double tmpT = (W_T - gamma_T) / xi_T;
        double tmpP = (W_P - gamma_P) / xi_P;
        g(0) = phi(tmpT);
        g(1) = phi(tmpP);
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
    idx = idx + 12;
  }
  return(mu);
}

arma::mat makeZetaVS(const int& t, const int& p, const arma::vec& day_len, 
                     const arma::mat& W, const double& Temp_min, 
                     const double& Temp_max, const double& P_min, 
                     const double& P_max){
  arma::mat mu(t, p, arma::fill::zeros);
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
      for(int s = 0; s < 12; s++){
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        arma::vec g(2, arma::fill::zeros);
        if(W_T < Temp_min){
          g(0) = 0;  
        } else if(W_T > Temp_max){
          g(0) = 1;
        } else {
          g(0) = (W_T - Temp_min) /
                 (Temp_max - Temp_min);
        }
        if(W_P < P_min){
          g(1) = 0;
        } else if(W_P > P_max){
          g(1) = 1;
        } else {
          g(1) = (W_P - P_min) /
                 (P_max - P_min);
        }
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
  }
  return(mu);
}