// [[Rcpp::depends(RcppArmadillo, myFunctions)]]
#include "myFunctionsHeader.h"

arma::vec makeBeta0(const arma::mat& y, const arma::mat& H, 
                     const arma::vec& beta_1, const arma::mat& zeta,
                     const arma::vec& species, const int& t, const int& p, 
                     const int& num_species, const arma::vec& s2){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += (y(i, k) - beta_1(species_idx) * zeta(i, k)) / 
                             s2(species_idx);
      }
    }
  }
  return(tmp);
}

arma::vec makeBeta1Mean(const arma::mat& y, const arma::mat& H, 
                         const arma::vec& beta_0, const arma::mat& zeta, 
                         const arma::vec& species, const int& t, const int& p,
                         const int& num_species, const arma::vec& s2){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += zeta(i, k) * (y(i, k) - beta_0(species_idx)) / 
                             s2(species_idx);
      }
    }
  }
  return(tmp);
}

arma::vec makeBeta1Var(const arma::mat& H, const arma::mat& zeta,
                       const arma::vec& species, const int& t, const int& p, 
                       const int& num_species, const arma::vec& s2){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += pow(zeta(i, k), 2) / s2(species_idx);
      }
    }
  }
  return(tmp);
}

arma::vec makeLikelihood(const arma::mat& y, const arma::mat& H, 
                         const arma::vec& beta_0, const arma::vec& beta_1,
                         const arma::mat& zeta, const int& t, const int& p,
                         const arma::vec& species, const arma::vec& s2){
  arma::vec tmp(t, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(i) += - 0.5 / s2(species_idx) * 
                   pow(y(i, k) - beta_0(species_idx) -
                       beta_1(species_idx) * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

double makeLikelihoodIndividual(const arma::mat& y, const arma::mat& H, 
                                const arma::vec& beta_0, 
                                const arma::vec& beta_1, 
                                const arma::vec& zeta_individual, const int& i,
                                const int& p, const arma::vec& species, 
                                const arma::vec& s2){
  double tmp = 0;
  for(int k = 0; k < p; k++){
    if(H(i, k)){
      int species_idx = species(k);
      tmp += - 0.5 / s2(species_idx) *
              pow(y(i, k) - beta_0(species_idx) - 
                   beta_1(species_idx) * zeta_individual(k), 2);
    }
  }
  return(tmp);
}


arma::vec makeLikelihoodSpecies(const arma::mat& y, const arma::mat& H, 
                                 const arma::vec& beta_0, 
                                 const arma::vec& beta_1, 
                                 const arma::mat& zeta, 
                                 const arma::vec& species, const int& t, 
                                 const int& p, const int& num_species,
                                 const arma::vec& s2){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += - 0.5 / s2(species_idx) *
                            pow(y(i, k) - beta_0(species_idx) -
                                 beta_1(species_idx) * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

arma::vec makeS2Beta(const arma::mat& y, const arma::mat& H,
                     const arma::vec& beta_0, const arma::vec& beta_1, 
                     const arma::mat& zeta, const arma::vec& species, 
                     const int& t, const int& p, const int& num_species){
  arma::vec tmp(num_species, arma::fill::zeros);
  for(int i = 0; i < t; i++){
    for(int k = 0; k < p; k++){
      if(H(i, k)){
        int species_idx = species(k);
        tmp(species_idx) += pow(y(i, k) - beta_0(species_idx) - 
                             beta_1(species_idx) * zeta(i, k), 2);
      }
    }
  }
  return(tmp);
}

arma::mat makeZetaIndividualNP(const int& p, const arma::vec& day_len,
                                 const arma::vec& W, const arma::vec& gamma_T,
                                 const arma::vec& xi_T, 
                                 const arma::vec& gamma_P,
                                 const arma::vec& xi_P, 
                                 const arma::vec& species){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
      int spec_idx = species(k);
    for(int s = 0; s < 12; s++){
      arma::vec g(2, arma::fill::zeros);
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
      double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
      g(0) = exp( - pow(tmpT, 2));
      g(1) = phi(tmpP);
      mu_tmp(s) = day_len(s) * min(g);
    }
  mu(k) = sum(mu_tmp);
  }
  return(mu);
}

arma::mat makeZetaIndividualPro(const int& p, const arma::vec& day_len,
                                 const arma::vec& W, const arma::vec& gamma_T,
                                 const arma::vec& xi_T, 
                                 const arma::vec& gamma_P,
                                 const arma::vec& xi_P, 
                                 const arma::vec& species){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
      int spec_idx = species(k);
    for(int s = 0; s < 12; s++){
      arma::vec g(2, arma::fill::zeros);
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
      double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
      g(0) = phi(tmpT);
      g(1) = phi(tmpP);
      mu_tmp(s) = day_len(s) * min(g);
    }
  mu(k) = sum(mu_tmp);
  }
  return(mu);
}

arma::vec makeZetaIndividualVS(const int& p, const arma::vec& day_len, 
                               const arma::vec& W, const arma::vec& Temp_min,
                               const arma::vec& Temp_max, 
                               const arma::vec& P_min, const arma::vec& P_max,
                               const arma::vec& species){
  arma::vec mu(p, arma::fill::zeros);
  for(int k = 0; k < p; k++){
    arma::vec mu_tmp(12, arma::fill::zeros);
    int spec_idx = species(k);
    for(int s = 0; s < 12; s++){
      double W_T = W(s);
      double W_P = exp(W(s + 12));
      arma::vec g(2, arma::fill::zeros);
      if(W_T < Temp_min(spec_idx)){
        g(0) = 0;  
      } else if(W_T > Temp_max(spec_idx)){
        g(0) = 1;
      } else {
        g(0) = (W_T - Temp_min(spec_idx)) / 
               (Temp_max(spec_idx) - Temp_min(spec_idx));
      }
      if(W_P < P_min(spec_idx)){
        g(1) = 0;
      } else if(W_P > P_max(spec_idx)){
        g(1) = 1;
      } else {
        g(1) = (W_P - P_min(spec_idx)) / 
               (P_max(spec_idx) - P_min(spec_idx));
      }
      mu_tmp(s) = day_len(s) * min(g);
    }
    mu(k) = sum(mu_tmp);
  }
  return(mu);
}

arma::mat makeZetaNP(const int& t, const int& p, const arma::vec& day_len, 
                       const arma::mat& W, const arma::vec& gamma_T, 
                       const arma::vec& xi_T, const arma::vec& gamma_P, 
                       const arma::vec& xi_P, const arma::vec& species){
  arma::mat mu(t, p, arma::fill::zeros);
  int idx = 0;
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
       int spec_idx = species(k);
      for(int s = 0; s < 12; s++){
        arma::vec g(2, arma::fill::zeros);
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
        double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
        g(0) = exp( - pow(tmpT, 2));
        g(1) = phi(tmpP);
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
    idx = idx + 12;
  }
  return(mu);
}

arma::mat makeZetaPro(const int& t, const int& p, const arma::vec& day_len, 
                       const arma::mat& W, const arma::vec& gamma_T, 
                       const arma::vec& xi_T, const arma::vec& gamma_P, 
                       const arma::vec& xi_P, const arma::vec& species){
  arma::mat mu(t, p, arma::fill::zeros);
  int idx = 0;
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
       int spec_idx = species(k);
      for(int s = 0; s < 12; s++){
        arma::vec g(2, arma::fill::zeros);
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        double tmpT = (W_T - gamma_T(spec_idx)) / xi_T(spec_idx);
        double tmpP = (W_P - gamma_P(spec_idx)) / xi_P(spec_idx);
        g(0) = phi(tmpT);
        g(1) = phi(tmpP);
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
    idx = idx + 12;
  }
  return(mu);
}

arma::mat makeZetaVS(const int& t, const int& p, const arma::vec& day_len, 
                     const arma::mat& W, const arma::vec& Temp_min, 
                     const arma::vec& Temp_max, const arma::vec& P_min, 
                     const arma::vec& P_max, const arma::vec& species){
  arma::mat mu(t, p, arma::fill::zeros);
  for(int i = 0; i < t; i++){  
    for(int k = 0; k < p; k++){
      arma::vec mu_tmp(12, arma::fill::zeros);
      int spec_idx = species(k);
      for(int s = 0; s < 12; s++){
        double W_T = W(s, i);
        double W_P = exp(W(s + 12, i));
        arma::vec g(2, arma::fill::zeros);
        if(W_T < Temp_min(spec_idx)){
          g(0) = 0;  
        } else if(W_T > Temp_max(spec_idx)){
          g(0) = 1;
        } else {
          g(0) = (W_T - Temp_min(spec_idx)) /
                 (Temp_max(spec_idx) - Temp_min(spec_idx));
        }
        if(W_P < P_min(spec_idx)){
          g(1) = 0;
        } else if(W_P > P_max(spec_idx)){
          g(1) = 1;
        } else {
          g(1) = (W_P - P_min(spec_idx)) /
                 (P_max(spec_idx) - P_min(spec_idx));
        }
        mu_tmp(s) = day_len(s) * min(g);
      }
      mu(i, k) = sum(mu_tmp);
    }
  }
  return(mu);
}