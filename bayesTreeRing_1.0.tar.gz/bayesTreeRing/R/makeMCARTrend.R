#' An R wrapper for the MCAR climate model with trend
#'
#' @param Temp A matrix of temperature data
#' @param P A matrix of log precipitation data
makeMCARTrend <- function(Temp, P){
##
## Libraries and functions
##

	
# source('~/treeRing/biomodel/climate/mcmcMakeMCARTrend.R')
# Rcpp::sourceCpp('~/treeRing/biomodel/climate/mcmcMakeMCARTrendRcpp.cpp')

make_Q_inv <- function(theta, t){ ## CAR precision matrix
	diag(t) + diag(c(0, rep(theta^2, t - 2), 0)) - theta * toeplitz(c(0, 1, rep(0, t - 2)))
}


mu_T <- apply(Temp, 1, mean)
s_T <- apply(Temp, 1, sd)
mu_P <- apply(P, 1, mean)
s_P <- apply(P, 1, sd)
T_prime <- (Temp - mu_T) / s_T
P_prime <- (P - mu_P) / s_P

climate <- as.matrix(rbind(T_prime, P_prime))

mu_beta_0 <- 0
s2_beta_0 <- 10
mu_beta_1 <- 0
s2_beta_1 <- 10
alpha_s2_W <- 1
beta_s2_W <- 1
alpha_rho_one <- 1
beta_rho_one <- 1
alpha_rho_two <- 1
beta_rho_two <- 1
alpha_phi_one <- 1
beta_phi_one <- 1
alpha_phi_two <- 1
beta_phi_two <- 1
phi_one_tune <- 0.07
phi_two_tune <- 0.07
rho_one_tune <- 0.05
rho_two_tune <- 0.05
omega_tune <- 0.05
n_iter <- 5000

params <- list("mu_beta_0" = mu_beta_0,
							 "s2_beta_0" = s2_beta_0, 
							 "mu_beta_1" = mu_beta_1, 
							 "s2_beta_1" = s2_beta_1, 
							 "alpha_s2_W" = alpha_s2_W, 
							 "beta_s2_W" = beta_s2_W,
							 "alpha_rho_one" = alpha_rho_one, 
							 "beta_rho_one" = beta_rho_one,
							 "alpha_rho_two" = alpha_rho_two,
							 "beta_rho_two" = beta_rho_two,
							 "alpha_phi_one" = alpha_phi_one,
							 "beta_phi_one" = beta_phi_one,
							 "alpha_phi_two" = alpha_phi_two, 
							 "beta_phi_two" = beta_phi_two,
							 "phi_one_tune" = phi_one_tune,
							 "phi_two_tune" = phi_two_tune, 
							 "rho_one_tune" = rho_one_tune, 
							 "rho_two_tune" = rho_two_tune, 
							 "omega_tune" = omega_tune, 
							 "n_mcmc" = n_iter)

##
## Run MCMC
##

out <- mcmcMCARR(climate, params)
# system.time(mcmcMCARR(climate, params))
# out <- mcmcMCAR(climate, params)
# system.time(mcmcMCAR(climate, params))

##
## Plot output
##

# layout(matrix(1:9, 3, 3))
# plot(out$beta_0, type = 'l', main = expression(beta[0]), ylab = expression(beta[0]))
# plot(out$beta_1, type = 'l', main = expression(beta[1]), ylab = expression(beta[0]))
# plot(out$phi_one, type = 'l', main = round(out$phi_one_accept, 4), ylab = expression(phi[1]))
# plot(out$phi_two, type = 'l', main = round(out$phi_two_accept, 4), ylab = expression(phi[2]))
# plot(out$rho_one, type = 'l', main = round(out$rho_one_accept, 4), ylab = expression(rho[1]))
# plot(out$rho_two, type = 'l', main = round(out$rho_two_accept, 4), ylab = expression(rho[2]))
# plot(out$omega, type = 'l', main = round(out$omega_accept, 4), ylab = expression(omega))
# plot(out$s2_W, type = 'l', main = expression(sigma[W]^2), ylab = expression(sigma[W]^2))

phi_one <- median(out$phi_one)
phi_two <- median(out$phi_two)
phi_vec <- c(rep(phi_one, 12), rep(phi_two, 12))
rho_one <- median(out$rho_one)
rho_two <- median(out$rho_two)
omega <- median(out$omega)
s2_W <- median(out$s2_W)
Q_1_inv <- make_Q_inv(rho_one, 12)
Q_1_minus_one_half <- chol(Q_1_inv)
Q_2_inv <- make_Q_inv(rho_two, 12)
Q_2_minus_one_half <- chol(Q_2_inv)
Q_upper_right <- t(Q_1_minus_one_half) %*% Q_2_minus_one_half
Q_inv <- rbind(cbind(Q_1_inv / (1 - omega^2), - omega / (1 - omega^2) * Q_upper_right), cbind( - omega / (1 - omega^2) * t(Q_upper_right), Q_2_inv / (1 - omega^2)))
Sigma_inv <- 1 / s2_W * Q_inv

list(phi_vec = phi_vec, Sigma_inv = Sigma_inv, trend_0 = median(out$beta_0), trend_1 = median(out$beta_1))
}
