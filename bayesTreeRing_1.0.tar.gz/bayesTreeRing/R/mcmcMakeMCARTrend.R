#' An R MCMC sampler for the MCAR climate model with trend
#'
#' @param climate A matrix of climate data
#' @param params A list of model parameters
mcmcMCARR <- function(climate, params){

	##
	## Libraries and Functions
	## 
	
  library(myFunctions)
# 	Rcpp::sourceCpp('~/treeRing/biomodel/treeRing.cpp')
# 	Rcpp::sourceCpp('~/functions/rMVNArma.cpp')	
# 	Rcpp::sourceCpp('~/functions/mvrnormARMA.cpp')	
# 	
	make_Q_inv <- function(theta, t){ ## CAR precision matrix
		diag(t) + diag(c(0, rep(theta^2, t - 2), 0)) - theta * toeplitz(c(0, 1, rep(0, t - 2)))
	}
	
	##
	## load parameters
	##
	
	mu_beta_0 <- params$mu_beta_0
	s2_beta_0 <- params$s2_beta_0
	mu_beta_1 <- params$mu_beta_1
	s2_beta_1 <- params$s2_beta_1
	alpha_s2_W <- params$alpha_s2_W
	beta_s2_W <- params$beta_s2_W
	alpha_rho_one <- params$alpha_rho_one
	beta_rho_one <- params$beta_rho_one
	alpha_rho_two <- params$alpha_rho_two
	beta_rho_two <- params$beta_rho_two
	alpha_phi_one <- params$alpha_phi_one
	beta_phi_one <- params$beta_phi_one
	alpha_phi_two <- params$alpha_phi_two
	beta_phi_two <- params$beta_phi_two
	phi_one_tune <- params$phi_one_tune
	phi_two_tune <- params$phi_two_tune
	rho_one_tune <- params$rho_one_tune
	rho_two_tune <- params$rho_two_tune
	omega_tune <- params$omega_tune
  n_mcmc <- params$n_mcmc
	
	make_Q_inv <- function(theta, t){ ## CAR precision matrix
		diag(t) + diag(c(0, rep(theta^2, t - 2), 0)) - theta * toeplitz(c(0, 1, rep(0, t - 2)))
	}
	
	t <- dim(climate)[2]
	phi_lower <- - 1
	phi_upper <- 1
	rho_lower <- - 1
	rho_upper <- 1
	omega_lower <- - 1
	omega_upper <- 1
	J <- c(rep(1, 12), rep(0, 12))
	tJ <- t(J)
  
	I12 <- diag(12)
# 	phi_one <- runif(1, phi_lower, phi_upper)
# 	phi_two <- runif(1, phi_lower, phi_upper)
	phi_one <- rbeta(1, alpha_phi_one, beta_phi_one) * (phi_upper - phi_lower) + phi_lower
	phi_two <- rbeta(1, alpha_phi_two, beta_phi_two) * (phi_upper - phi_lower) + phi_lower
	phi_vec <- c(rep(phi_one, 12), rep(phi_two, 12))

#   rho_one <- runif(1, rho_lower, rho_upper)
# 	rho_two <- runif(1, rho_lower, rho_upper)
	rho_one <- rbeta(1, alpha_rho_one, beta_rho_one) * (rho_upper - rho_lower) + rho_lower
	rho_two <- rbeta(1, alpha_rho_two, beta_rho_two) * (rho_upper - rho_lower) + rho_lower
	omega <- runif(1, omega_lower, omega_upper)
	s2_W <- 1 / rgamma(1, alpha_s2_W, beta_s2_W)
  Q_1_inv <- make_Q_inv(rho_one, 12)
	Q_1_minus_one_half <- chol(Q_1_inv)
	Q_2_inv <- make_Q_inv(rho_two, 12)
	Q_2_minus_one_half <- chol(Q_2_inv)
	Q_upper_right <- t(Q_1_minus_one_half) %*% Q_2_minus_one_half
	Q_inv <- rbind(cbind(Q_1_inv / (1 - omega^2), - omega / (1 - omega^2) * Q_upper_right), cbind( - omega / (1 - omega^2) * t(Q_upper_right), Q_2_inv / (1 - omega^2)))
	Sigma_inv <- 1 / s2_W * Q_inv
	det_Sigma <- - determinant(Sigma_inv, logarithm = TRUE)$modulus[1]	

	beta_0 <- rnorm(1, mu_beta_0, sqrt(s2_beta_0))
	beta_1 <- rnorm(1, mu_beta_1, sqrt(s2_beta_1))

	##
	## save variables
	##
	
	n_burn <- n_mcmc / 2
	n_save <- n_mcmc - n_burn
	beta_0_save <- rep(0, n_save)
	beta_1_save <- rep(0, n_save)
	phi_one_save <- rep(0, n_save) 
	phi_one_accept <- 0
  phi_two_save <- rep(0, n_save)
	phi_two_accept <- 0
	rho_one_save <- rep(0, n_save)
	rho_one_accept <- 0
	rho_two_save <- rep(0, n_save)
	rho_two_accept <- 0
	omega_save <- rep(0, n_save)
	omega_accept <- 0
	s2_W_save <- rep(0, n_save)
	log_deviance <- rep(0, n_save)
	y_pred <- array(0, c(t - 1, 24, n_save))
	
	##
	## Run MCMC
	##
	
	for(k in 1:n_mcmc){
		if(k %% 100 == 0){
			cat(k, ' ')
		}
		
		##
		## sample phi_one
		##
		
		phi_one_star <- rnorm(1, phi_one, phi_one_tune)
		if(phi_one_star > phi_lower && phi_one_star < phi_upper){
			phi_vec_star <- c(rep(phi_one_star, 12), rep(phi_two, 12))
			mh_log <- samplePhi(climate, phi_vec, phi_vec_star, Sigma_inv, t, beta_0, beta_1, J) + dbeta((phi_one_star - phi_lower) / (phi_upper - phi_lower), alpha_phi_one, beta_phi_one, log = TRUE) - dbeta((phi_one - phi_lower) / (phi_upper - phi_lower), alpha_phi_one, beta_phi_one, log = TRUE)			
			mh <- exp(mh_log)
			if(mh > runif(1)){
				phi_one <- phi_one_star
				phi_vec <- phi_vec_star
      	phi_one_accept <- phi_one_accept + 1 / n_mcmc
			}		
			## remove variables
			rm(mh); rm(phi_one_star); rm(phi_vec_star)
		}
		
		##
		## sample phi_two
		##
		
		phi_two_star <- rnorm(1, phi_two, phi_two_tune)
		if(phi_two_star > phi_lower && phi_two_star < phi_upper){
			phi_vec_star <- c(rep(phi_one, 12), rep(phi_two_star, 12))
			mh_log <- samplePhi(climate, phi_vec, phi_vec_star, Sigma_inv, t, beta_0, beta_1, J) + dbeta((phi_two_star - phi_lower) / (phi_upper - phi_lower), alpha_phi_two, beta_phi_two, log = TRUE) - dbeta((phi_two - phi_lower) / (phi_upper - phi_lower), alpha_phi_two, beta_phi_two, log = TRUE)
			mh <- exp(mh_log)
			if(mh > runif(1)){
				phi_two <- phi_two_star
				phi_vec <- phi_vec_star
				phi_two_accept <- phi_two_accept + 1 / n_mcmc
			}		
			## remove variables
			rm(mh); rm(phi_two_star); rm(phi_vec_star)
		}

		##
		## sample rho_one
		##
		
		rho_one_star <- rnorm(1, rho_one, rho_one_tune)
		if(rho_one_star > rho_lower && rho_one_star < rho_upper){
			Q_1_inv_star <- make_Q_inv(rho_one_star, 12)
			Q_1_minus_one_half_star <- chol(Q_1_inv_star)
			Q_upper_right_star <- t(Q_1_minus_one_half_star) %*% Q_2_minus_one_half
			Q_inv_star <- rbind(cbind(Q_1_inv_star / (1 - omega^2), - omega / (1 - omega^2) * Q_upper_right_star), cbind( - omega / (1 - omega^2) * t(Q_upper_right_star), Q_2_inv / (1 - omega^2)))
			Sigma_inv_star <- 1 / s2_W * Q_inv_star
			det_Sigma_star <- - determinant(Sigma_inv_star, logarithm = TRUE)$modulus[1]
			mh_log <- sampleRho(climate, phi_vec, Sigma_inv, Sigma_inv_star, det_Sigma, det_Sigma_star, t, beta_0, beta_1, J) + dbeta((rho_one_star - rho_lower) / (rho_upper - rho_lower), alpha_rho_one, beta_rho_one, log = TRUE) - dbeta((rho_one - rho_lower) / (rho_upper - rho_lower), alpha_rho_one, beta_rho_one, log = TRUE)
			mh <- exp(mh_log)
			if(mh > runif(1)){
			  rho_one <- rho_one_star
		  	Q_1_inv <- Q_1_inv_star
			  Q_1_minus_one_half <- Q_1_minus_one_half_star
			  Q_upper_right <- Q_upper_right_star
			  Q_inv <- Q_inv_star
		  	Sigma_inv <- Sigma_inv_star
			  det_Sigma <- det_Sigma_star
			  rho_one_accept <- rho_one_accept + 1 / n_mcmc
			}
			## remove variables
			rm(mh, rho_one_star, Q_1_inv_star, Q_1_minus_one_half_star, Q_upper_right_star, Q_inv_star, det_Sigma_star, Sigma_inv_star)
		}
		
		##
		## sample rho_two
		##
		
		rho_two_star <- rnorm(1, rho_two, rho_two_tune)
		if(rho_two_star > rho_lower && rho_two_star < rho_upper){
			Q_2_inv_star <- make_Q_inv(rho_two_star, 12)
			Q_2_minus_one_half_star <- chol(Q_2_inv_star)
			Q_upper_right_star <- t(Q_1_minus_one_half) %*% Q_2_minus_one_half_star
			Q_inv_star <- rbind(cbind(Q_1_inv / (1 - omega^2), - omega / (1 - omega^2) * Q_upper_right_star), cbind( - omega / (1 - omega^2) * t(Q_upper_right_star), Q_2_inv_star / (1 - omega^2)))
			Sigma_inv_star <- 1 / s2_W * Q_inv_star
			det_Sigma_star <- - determinant(Sigma_inv_star, logarithm = TRUE)$modulus[1]
			mh_log <- sampleRho(climate, phi_vec, Sigma_inv, Sigma_inv_star, det_Sigma, det_Sigma_star, t, beta_0, beta_1, J) + dbeta((rho_two_star - rho_lower) / (rho_upper - rho_lower), alpha_rho_two, beta_rho_two, log = TRUE) - dbeta((rho_two - rho_lower) / (rho_upper - rho_lower), alpha_rho_two, beta_rho_two, log = TRUE)
			mh <- exp(mh_log)
			if(mh > runif(1)){
				rho_two <- rho_two_star
				Q_2_inv <- Q_2_inv_star
				Q_2_minus_one_half <- Q_2_minus_one_half_star
				Q_upper_right <- Q_upper_right_star
				Q_inv <- Q_inv_star
				Sigma_inv <- Sigma_inv_star
				det_Sigma <- det_Sigma_star
				rho_two_accept <- rho_two_accept + 1 / n_mcmc
			}
			## remove variables
			rm(mh, rho_two_star, Q_2_inv_star, Q_2_minus_one_half_star, Q_upper_right_star, Q_inv_star, det_Sigma_star, Sigma_inv_star)
		}
		##
		## sample omega
		##
		
		omega_star <- rnorm(1, omega, omega_tune)
		if(omega_star > omega_lower && omega_star < omega_upper){
			Q_inv_star <- rbind(cbind(Q_1_inv / (1 - omega_star^2), - omega_star / (1 - omega_star^2) * Q_upper_right), cbind( - omega_star / (1 - omega_star^2) * t(Q_upper_right), Q_2_inv / (1 - omega_star^2)))
			Sigma_inv_star <- 1 / s2_W * Q_inv_star
			det_Sigma_star <- - determinant(Sigma_inv_star, logarithm = TRUE)$modulus[1]
			mh <- sampleOmega(climate, phi_vec, Sigma_inv, Sigma_inv_star, det_Sigma, det_Sigma_star, t , beta_0, beta_1, J)
			if(mh > runif(1)){
				omega <- omega_star
				Q_inv <- Q_inv_star
				Sigma_inv <- Sigma_inv_star
				det_Sigma <- det_Sigma_star
				omega_accept <- omega_accept + 1 / n_mcmc
			}
			## remove variables
			rm(mh, omega_star, Q_inv_star, det_Sigma_star, Sigma_inv_star)
		}
		
		##
		## sample s2_W
		##
		
		s2_W <- 1 / rgamma(1, alpha_s2_W + 24 * (t - 1) / 2, 
																	beta_s2_W + 1 / 2 * 
																	sampleSigmaSquaredW(climate, phi_vec, Q_inv, t, beta_0, 
																											beta_1, J))
		Sigma_inv <- 1 / s2_W * Q_inv
		det_Sigma <- - determinant(Sigma_inv, logarithm = TRUE)$modulus[1]
		
		## 
		## sample beta_0
		##
		
		Jphi_vecJ <- - J + phi_vec * J
		tJphi_vecJ <- t(Jphi_vecJ)
		A <- (t - 1) * tJphi_vecJ %*% Sigma_inv %*% Jphi_vecJ + 1 / s2_beta_0
		b <- mu_beta_0 / s2_beta_0
		for(i in 2:t){
			b <- b + - tJphi_vecJ %*% Sigma_inv %*% (climate[, i] - beta_1 * (i - 1) * J - phi_vec * (climate[, i - 1] - beta_1 * (i - 2) * J))
		}
		beta_0 <- myFunctions::rMVNArma(A, b)
		## remove variables
		rm(Jphi_vecJ, tJphi_vecJ, A, b)
		
		## 
		## sample beta_1
		##
		
		A <- 1 / s2_beta_1
		b <- mu_beta_1 / s2_beta_1
		for(i in 2:t){
			Jphi_vecJ <- ( - (i - 1) * J + (i - 2) * phi_vec * J) 
			tJphi_vecJ <- t(Jphi_vecJ)
			A <- A + tJphi_vecJ %*% Sigma_inv %*% Jphi_vecJ# + 1 / s2_beta_1
			b <- b + - tJphi_vecJ %*% Sigma_inv %*% (climate[, i] - beta_0 * J - phi_vec * (climate[, i - 1] - beta_0 * J))
		}
		beta_1 <- myFunctions::rMVNArma(A, b)
		## remove variables
		rm(Jphi_vecJ, tJphi_vecJ, A, b)
		
		##
		## save variables
		##
		
		if(k > n_burn){
			ktmp <- k - n_burn
			
			##
			## One step ahead posterior predictions
			##
			
# 			Sigma <- solve(Sigma_inv)
# 			for(l in 2:t){
# 				y_pred[l - 1, , ktmp] <- mvrnormArma(1, beta_0 * J + beta_1 * (l - 1) * J + phi_vec * (climate[, l - 1] - beta_0 * J - beta_1 * (l - 2) * J), Sigma)
# 			}
			
			##
			## DIC calculation
			##
		
# 			for(l in 2:t){
# 				log_deviance[ktmp] <- log_deviance[ktmp] - 24 / 2 * log(2 * pi) - 1 / 2 * det_Sigma - 1 / 2 * t(climate[, l] - beta_0 * J - beta_1 * (l - 1)* J - phi_vec * (climate[, l - 1] - beta_0 * J - beta_1 * (l - 2) * J)) %*% Sigma_inv %*% (climate[, l] - beta_0 * J - beta_1 * (l - 1)* J - phi_vec * (climate[, l - 1] - beta_0 * J - beta_1 * (l - 2) * J))
# 			}
			
			## save variables
			beta_0_save[ktmp] <- beta_0
			beta_1_save[ktmp] <- beta_1
			phi_one_save[ktmp] <- phi_one
			phi_two_save[ktmp] <- phi_two
			rho_one_save[ktmp] <- rho_one
			rho_two_save[ktmp] <- rho_two
			omega_save[ktmp] <- omega
			s2_W_save[ktmp] <- s2_W
		}
	}
	##
	## calculate DIC
	##
	
# 	beta_0_mn <- mean(beta_0_save)
# 	beta_1_mn <- mean(beta_1_save)
# 	phi_vec_mn <- c(rep(mean(phi_one_save), 12), rep(mean(phi_two_save), 12))
# 	Q_1_inv_mn <- make_Q_inv(mean(rho_one_save), 12)
# 	Q_1_minus_one_half_mn <- chol(Q_1_inv_mn)
# 	Q_2_inv_mn <- make_Q_inv(mean(rho_two_save), 12)
# 	Q_2_minus_one_half_mn <- chol(Q_2_inv_mn)
# 	Q_upper_right_mn <- t(Q_1_minus_one_half_mn) %*% Q_2_minus_one_half_mn
#   omega_mn <- mean(omega_save)
# 	Q_inv_mn <- rbind(cbind(Q_1_inv_mn / (1 - omega_mn^2), - omega_mn / (1 - omega_m^2) * Q_upper_right_mn), cbind( - omega_mn / (1 - omega_mn^2) * t(Q_upper_right_mn), Q_2_inv_mn / (1 - omega_mn^2)))
# 	Sigma_inv_mn <- 1 / mean(s2_W_save) * Q_inv_mn
# 	det_Sigma_mn <- - determinant(Sigma_inv_mn, logarithm = TRUE)$modulus[1]	
# 	
# 	log_deviance_post <- 0
# 	for(l in 2:t){
# 		log_deviance_post <- log_deviance_post - 24 / 2 * log(2 * pi) - 1 / 2 * det_Sigma_mn - 1 / 2 * t(climate[, l] - beta_0_mn * J - beta_1_mn * (l - 1)* J - phi_vec_mn * (climate[, l - 1] - beta_0_mn * J - beta_1_mn * (l - 2) * J)) %*% Sigma_inv_mn %*% (climate[, l] - beta_0_mn * J - beta_1_mn * (l - 1)* J - phi_vec_mn * (climate[, l - 1] - beta_0_mn * J - beta_1_mn * (l - 2) * J))
# 	}
# 	
# 	p_DIC <- 2 * (log_deviance_post - mean(log_deviance))
# 	DIC <- - 2 * log_deviance_post + 2 * p_DIC
	
	##
	## List output
	##
	
	list(beta_0 = beta_0_save, beta_1 = beta_1_save, phi_one = phi_one_save, phi_two = phi_two_save, rho_one = rho_one_save, rho_two = rho_two_save, omega = omega_save, s2_W = s2_W_save, phi_one_accept = phi_one_accept, phi_two_accept = phi_two_accept, rho_one_accept = rho_one_accept, rho_two_accept = rho_two_accept, omega_accept = omega_accept)
}
